# R1 Game Pack Template

Copy this directory as the starting point for a new game pack.

## Required workflow

1. Replace `manifest.json` identity/version.
2. Implement rules in `server.js` and/or `domain/`.
3. Keep authoritative rule callbacks synchronous.
4. Use explicit `project()` for every viewer.
5. Keep `server.js` outside all public directories.
6. Run `npm run audit:pack -- ./templates/game-pack-r1` from the engine root.
7. Build a golden replay/save scenario before signing the ZIP.
8. Sign the final ZIP for production installation.

See `GAME_PACK_REFACTOR_GUIDE_1.40.111_R1.md` for the full audit checklist.
