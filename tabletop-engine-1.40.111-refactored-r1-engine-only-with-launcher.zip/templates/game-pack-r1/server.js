'use strict';

module.exports = {
  id: 'example-r1-game',

  createState() {
    return {
      round: 1,
      score: {},
    };
  },

  project(state, viewer, snapshot) {
    return {
      ...snapshot,
      public: {
        round: state.round,
        score: state.score[viewer] || 0,
      },
    };
  },

  actions: {
    SCORE(ctx) {
      ctx.state.score[ctx.actor] = (ctx.state.score[ctx.actor] || 0) + 1;
    },
    END_TURN(ctx) {
      ctx.endTurn();
    },
  },
};
