Public pack assets belong here. Never place server-side secrets in this directory.
