# Game Pack Security Policy

## Production policy
Distribution ZIP game packs are verified with Ed25519 before extraction and before execution. The signature covers the canonical manifest plus SHA-256 hashes of every pack file except the manifest itself. ZIP path traversal, duplicate entries, oversized entries and total decompression limits are rejected.

The engine trusts only packs carrying the bundled official public key (`runtime/trust/pack-ed25519-public.pem`). Unsigned ZIPs are rejected by default.

## Development
Set `TABLETOP_ALLOW_UNSIGNED_PACKS=1` only in a controlled development environment. Unpacked game directories remain a development-only convenience and are not a security boundary.

## Sandbox decision
Cryptographic signing is a provenance/integrity boundary, not a JavaScript sandbox. A signed game pack is therefore treated as trusted executable code. Truly untrusted third-party packs must be run in a separate OS/container process with a reduced filesystem/network/user privilege set; the in-process engine deliberately does not pretend to sandbox CommonJS game rules.

## Signing
The distribution builder accepts `TABLETOP_PACK_SIGNING_PRIVATE_KEY_FILE` (or `TABLETOP_PACK_SIGNING_PRIVATE_KEY`) and embeds only the resulting signature, never the private key.

## R1 operational hardening

Pack installation is staged. The engine validates manifest/compatibility/signature before replacing an existing archive, retains the previous version as rollback backup until the new version loads successfully, and includes the source archive SHA-256 in installed cache identity.

Pack public files are fail-closed. Unless `manifest.publicPaths` is declared, only `preview/`, `player-ui/`, `tv-ui/`, `assets/` and `public/` are exposed through the HTTP game route. The server entrypoint is not a public asset.

Pack Manager mutation endpoints require an explicit admin token in production deployments. See `DISTRIBUTION_ARCHITECTURE_1.40.111.md` and `GAME_PACK_REFACTOR_GUIDE_1.40.111_R1.md`.
