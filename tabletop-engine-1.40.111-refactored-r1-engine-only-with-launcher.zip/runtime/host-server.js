'use strict';
const http=require('node:http');
const {createServer:createWsServer}=require('./server/websocket');
const {MatchHost}=require('./server/match-host');
const {GamePackHost}=require('./pack-host');
const {serve:serveLauncher}=require('../launcher/server');

const engineVersion=require('../package.json').version;
const packHost=new GamePackHost({engineVersion,packDir:process.env.TABLETOP_GAME_PACKS_DIR});
const hosts=new Map();
function parsePath(requestPath){
  const u=new URL(requestPath||'/', 'ws://tabletop');
  const m=u.pathname.match(/^\/games\/([^/]+)$/);
  if(!m) return null;
  return {gameId:decodeURIComponent(m[1]),matchId:String(u.searchParams.get('match')||'default')};
}
function getGameHost(gameId){
  if(hosts.has(gameId)) return hosts.get(gameId);
  const h=new MatchHost({disconnectGraceMs:120000,maxMatches:Number(process.env.TABLETOP_MAX_MATCHES_PER_GAME||64),idleMatchTtlMs:Number(process.env.TABLETOP_MATCH_IDLE_TTL_MS||0)});
  hosts.set(gameId,h); h.createMatch('default',()=>packHost.load(gameId).definition);
  return h;
}
let activeServer=null;
let pruneTimer=null;
let stopping=false;
function startServer(){
 if(activeServer) return activeServer.ready;
 const ws=createWsServer({port:Number(process.env.DEVICE_WS_PORT||process.env.WS_PORT||8080),host:process.env.DEVICE_HOST||process.env.WS_HOST||'0.0.0.0',onSession(session){
  try{
   const route=parsePath(session.path); if(!route) return session.close(1008);
   const host=getGameHost(route.gameId);
   const autoCreate=process.env.TABLETOP_AUTO_CREATE_MATCHES==='1' || (process.env.NODE_ENV!=='production' && process.env.TABLETOP_AUTO_CREATE_MATCHES!=='0');
   if(!host.getMatch(route.matchId)){if(!autoCreate)return session.close(1008);host.createMatch(route.matchId,()=>packHost.load(route.gameId).definition);}
   host.attach(route.matchId,session);
  }catch(error){session.close(1008);}
 }});
 const httpServer=http.createServer(serveLauncher); const httpPort=Number(process.env.PORT||8090);
 const server={ws,httpServer,ready:null};
 activeServer=server;
 server.ready=Promise.all([
  ws.listen(),
  new Promise((resolve,reject)=>{httpServer.once('error',reject);httpServer.listen(httpPort,'0.0.0.0',resolve);})
 ]).then(()=>{
  console.log(`Tabletop Engine ${engineVersion}: HTTP ${httpPort}, WebSocket ${process.env.DEVICE_WS_PORT||process.env.WS_PORT||8080}, game-packs=${packHost.packDir}`);
  return server;
 }).catch(async error=>{
  await stopServer(server);
  throw error;
 });
 return server.ready;
}
async function stopServer(server=activeServer){
 if(pruneTimer){clearInterval(pruneTimer);pruneTimer=null;}
 if(stopping) return;
 stopping=true;
 const target=server||{};
 for(const h of hosts.values())for(const id of [...h.matches.keys()])h.removeMatch(id);
 const tasks=[];
 if(target.ws?.close) tasks.push(Promise.resolve(target.ws.close()).catch(()=>{}));
 if(target.httpServer?.close) tasks.push(new Promise(resolve=>target.httpServer.close(()=>resolve())).catch(()=>{}));
 await Promise.all(tasks);
 if(target===activeServer) activeServer=null;
 stopping=false;
}

if(require.main===module){
 startServer().catch(error=>{console.error(error);process.exitCode=1;});
 const onSignal=async()=>{await stopServer();process.exitCode=0;};
 process.once('SIGINT',onSignal);
 process.once('SIGTERM',onSignal);
}
module.exports={packHost,hosts,parsePath,getGameHost,startServer,stopServer};
