# ReconnectingClient

Transport-agnostic client session helper.

It keeps the player ID, resume token, last event cursor and pending command
CIDs. The actual WebSocket implementation is injected through `connect()`.

On disconnect it retries with exponential backoff, reconnects using the resume
token and re-sends pending commands with the original CID.

## Production join authentication

`SessionClient` and the browser `SessionClient` accept:

```js
new SessionClient({
  connect,
  match: 'match-1',
  principal: 'player-1',
  authToken: '<short-lived-join-token>'
});
```

`joinToken` is accepted as an alias for `authToken`.

The credential is sent only in the initial JOIN frame. It is separate from the
resume token used after an already-authenticated session reconnects.
