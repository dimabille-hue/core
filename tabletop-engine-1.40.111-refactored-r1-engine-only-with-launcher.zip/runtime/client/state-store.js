'use strict';

/** Genre-neutral client-side state holder. It never interprets game events. */
class ClientStateStore {
  constructor(options = {}) { this.snapshot = null; this.revision = 0; this.lastEvent = 0; this.lastEvents = { state: 0, presentation: 0 }; this.stateReducer = typeof options.stateReducer === 'function' ? options.stateReducer : null; }
  reset() { this.snapshot = null; this.revision = 0; this.lastEvent = 0; this.lastEvents = { state: 0, presentation: 0 }; }
  applySnapshot(message) {
    if (!message || !message.data) return false;
    this.snapshot = message.data;
    this.revision = Number(message.revision || this.snapshot.revision || 0);
    return true;
  }
  applyEvents(message) {
    if (!message || !Array.isArray(message.data)) return false;
    const stream = String(message.stream || 'state');
    for (const event of message.data) if (Number.isFinite(event.seq ?? event.id)) this.lastEvents[stream] = Math.max(this.lastEvents[stream] || 0, Number(event.seq ?? event.id));
    if (stream === 'state') {
      this.lastEvent = this.lastEvents.state || 0;
      if (this.stateReducer && this.snapshot) {
        for (const event of message.data) this.stateReducer(this.snapshot, event);
      }
    }
    this.revision = Math.max(this.revision, Number(message.revision || 0));
    return true;
  }
}
module.exports = { ClientStateStore };
