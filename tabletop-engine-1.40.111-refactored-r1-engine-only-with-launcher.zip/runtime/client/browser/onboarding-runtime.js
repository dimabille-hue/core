// AUTO-GENERATED BROWSER MODULE. DO NOT EDIT.
// Source: client/onboarding-runtime.js
// Source SHA-256: 13781ca831870e204338e664afdcd487aa1d47b510d0b6fd04a6a5751bb86d50

class OnboardingRuntime {
  constructor(options = {}) {
    this.client = options.client;
    this.viewer = options.viewer || null;
    this.plan = null;
    this.listeners = new Set();
    this.active = false;
    if (this.client) {
      const previous = this.client.onTutorial;
      this.client.onTutorial = (plan, msg) => {
        this.set(plan, msg);
        previous?.(plan, msg);
      };
    }
  }
  on(fn) { if (typeof fn !== 'function') throw new TypeError('listener-required'); this.listeners.add(fn); return () => this.listeners.delete(fn); }
  emit() { for (const fn of this.listeners) fn(this.plan); }
  set(plan, msg = null) { this.plan = plan ? { ...plan } : null; this.active = !!plan && plan.status === 'playing'; this.emit(); return msg; }
  complete({ skip = false } = {}) { if (!this.client || !this.active) return false; this.client.send({v:1,t:8,skip:!!skip}); return true; }
}
export { OnboardingRuntime };
