// AUTO-GENERATED BROWSER MODULE. DO NOT EDIT.
// Source: client/reconnecting-client.js
// Source SHA-256: b4170bc09ebc2adba015007429d7a1fbdd389371b1cdd96ab7761ecead1c444a

class ReconnectingClient {
  constructor(options = {}) {
    if (typeof options.connect !== 'function') throw new TypeError('connect-required');
    this.connect = options.connect;
    this.player = String(options.player || '');
    this.token = options.resumeToken || null;
    this.lastEvent = Number(options.lastEvent || 0);
    this.maxDelayMs = Math.max(100, Number(options.maxDelayMs ?? 5000));
    this.baseDelayMs = Math.max(50, Number(options.baseDelayMs ?? 250));
    this.onMessage = options.onMessage || (() => {});
    this.onState = options.onState || (() => {});
    this.socket = null;
    this.stopped = true;
    this.attempt = 0;
    this.nextCid = 1;
    this.pending = new Map();
    this.reconnectTimer = null;
  }
  start() { this.stopped = false; this.attempt = 0; return this.open(); }
  stop() { this.stopped = true; if (this.reconnectTimer) clearTimeout(this.reconnectTimer); this.reconnectTimer = null; if (this.socket?.close) this.socket.close(); this.socket = null; this.onState('stopped'); }
  async open() {
    if (this.stopped) return;
    this.onState('connecting');
    try {
      const socket = await this.connect();
      this.socket = socket;
      this.attempt = 0;
      socket.onmessage = evt => this.receive(typeof evt.data === 'string' ? JSON.parse(evt.data) : evt.data);
      socket.onclose = () => this.handleDisconnect();
      socket.onerror = () => this.handleDisconnect();
      socket.send(JSON.stringify({v:1,t:2,player:this.player,resumeToken:this.token,lastEvent:this.lastEvent}));
      for (const item of this.pending.values()) socket.send(JSON.stringify(item.frame));
      this.onState('connected');
    } catch (error) {
      this.onState('connect-error', error);
      this.scheduleReconnect();
    }
  }
  handleDisconnect() { if (this.stopped) return; if (!this.socket) return; this.socket = null; this.onState('disconnected'); this.scheduleReconnect(); }
  scheduleReconnect() {
    if (this.stopped) return;
    const delay = Math.min(this.maxDelayMs, this.baseDelayMs * (2 ** Math.min(this.attempt++, 6)));
    if (this.reconnectTimer) return; this.reconnectTimer = setTimeout(() => { this.reconnectTimer = null; this.open(); }, delay);
  }
  sendCommand(command, cid = null) {
    const id = cid == null ? `${Date.now().toString(36)}-${(this.nextCid++).toString(36)}` : String(cid);
    const frame = {v:1,t:3,cid:id,cmd:command};
    this.pending.set(id, {frame});
    if (this.socket) this.socket.send(JSON.stringify(frame));
    return id;
  }
  receive(msg) {
    if (!msg) return;
    if (msg.t === 108 || msg.t === 109) {
      if (msg.resumeToken) this.token = msg.resumeToken;
    }
    if (msg.t === 103 && Array.isArray(msg.data)) {
      for (const event of msg.data) if (Number.isFinite(event.id)) this.lastEvent = Math.max(this.lastEvent, event.id);
    }
    if (msg.t === 104 && msg.cid) this.pending.delete(String(msg.cid));
    if (msg.t !== 101) this.onMessage(msg);
  }
}
export { ReconnectingClient };
