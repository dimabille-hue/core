# Server Adapter v1.9

The server layer is transport/session infrastructure only. It has no dependency on a concrete game.

## Roles

- `player`: may send game commands and receives private + public projections.
- `viewer`: TV/display-style observer; receives public projections/events and cannot send game commands.

## Reconnect

Resume tokens are scoped to `(match, principal, role)`, expire, and rotate after successful resume. Command CIDs are retained at player scope so retry after reconnect is idempotent.

## Transport

The bundled WebSocket adapter is deliberately small and transport-focused. It accepts single-frame text messages, enforces a configurable frame limit and rejects fragmented/reserved frames. A full WebSocket implementation may be substituted without changing `MatchHost` or `core`.

## Production identity

Set `TABLETOP_JOIN_SECRET` and keep `TABLETOP_REQUIRE_AUTH=1` (or use `NODE_ENV=production`, where auth is required unless explicitly disabled). A `SessionClient` accepts `authToken` (alias `joinToken`) and sends it in the JOIN frame. Tokens are scoped to `(match, principal, role)` and expire.

Resume tokens are separate short-lived session credentials; they are not a substitute for the initial identity admission token on a fresh session.

## Resource limits

`MatchHost` supports `maxMatches` and `idleMatchTtlMs`. The bundled WebSocket adapter also limits handshake bytes, frame bytes and messages per second. These controls are application-level guardrails; public deployments should still use a rate-limiting reverse proxy where appropriate.
