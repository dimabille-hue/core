'use strict';

const crypto = require('node:crypto');

function timingSafeEqualText(a, b) {
  const aa = Buffer.from(String(a || ''));
  const bb = Buffer.from(String(b || ''));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

function sign(secret, value) {
  return crypto.createHmac('sha256', secret).update(value).digest('base64url');
}

/** Create a short-lived native join token for a specific match/principal/role. */
function issueJoinToken(secret, { match, principal, role = 'player', ttlMs = 60 * 60 * 1000, now = Date.now() }) {
  if (!secret) throw new Error('join-secret-required');
  const exp = Math.trunc(now + ttlMs);
  const payload = `${encodeURIComponent(match)}|${encodeURIComponent(principal)}|${encodeURIComponent(role)}|${exp}`;
  return `${Buffer.from(payload, 'utf8').toString('base64url')}.${sign(secret, payload)}`;
}

function verifyJoinToken(secret, token, { match, principal, role = 'player', now = Date.now() }) {
  if (!secret || typeof token !== 'string') return false;
  const [encoded, signature] = token.split('.');
  if (!encoded || !signature) return false;
  let payload;
  try { payload = Buffer.from(encoded, 'base64url').toString('utf8'); } catch { return false; }
  if (!timingSafeEqualText(signature, sign(secret, payload))) return false;
  const parts = payload.split('|');
  if (parts.length !== 4) return false;
  const [m, p, r, expRaw] = parts.map(decodeURIComponent);
  const exp = Number(expRaw);
  return m === String(match) && p === String(principal) && r === String(role) && Number.isFinite(exp) && exp >= now;
}

function requireAdminToken(req, expected) {
  if (!expected) return false;
  const provided = req.headers['x-tabletop-admin-token'];
  return !!provided && timingSafeEqualText(provided, expected);
}

module.exports = { issueJoinToken, verifyJoinToken, requireAdminToken };
