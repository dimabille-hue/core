'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { GamePackHost } = require('./pack-host');
const { readEntries, readEntry } = require('./zip-reader');
const { verifyPack } = require('./pack-signature');

function sanitizeFilename(name) {
  const base = path.basename(String(name || 'game-pack.zip')).replace(/[^A-Za-z0-9._-]+/g, '-');
  return base.toLowerCase().endsWith('.zip') ? base : `${base}.zip`;
}
function sha256(file) {
  const h = crypto.createHash('sha256');
  h.update(fs.readFileSync(file));
  return h.digest('hex');
}
function validateArchive(file, engineVersion, options = {}) {
  const entries = readEntries(file);
  const me = entries.get('manifest.json');
  if (!me) throw new Error('missing-manifest');
  const manifest = JSON.parse(readEntry(me).toString('utf8'));
  if (manifest.schemaVersion !== 1 || manifest.packFormatVersion !== 1) throw new Error('unsupported-pack-schema');
  const { compatible } = require('./pack-host');
  if (!compatible(manifest.engineCompatibility, engineVersion)) throw new Error(`incompatible-engine:${manifest.engineCompatibility}`);
  if (!manifest.gameId || !/^[a-z0-9][a-z0-9-]{0,63}$/.test(manifest.gameId)) throw new Error('invalid-game-id');
  if (!manifest.name || !manifest.version || !manifest.entry) throw new Error('invalid-manifest');
  if (!entries.has(manifest.entry)) throw new Error('missing-entry');
  if (!entries.has('preview/index.html')) throw new Error('missing-preview');
  if (Array.isArray(manifest.capabilities) && manifest.capabilities.includes('player') && !entries.has('player-ui/index.html')) throw new Error('missing-player-surface');
  if (Array.isArray(manifest.capabilities) && manifest.capabilities.includes('tv') && !entries.has('tv-ui/index.html')) throw new Error('missing-tv-surface');
  if (options.security === 'signature' && options.allowUnsigned !== true) {
    const buffers = [];
    for (const [entryName, entry] of entries) buffers.push([entryName, readEntry(entry)]);
    const verification = verifyPack(manifest, buffers);
    if (!verification.ok) throw new Error(`invalid-pack-signature:${verification.reason}`);
  }
  return manifest;
}

class PackManager {
  constructor(options = {}) {
    this.engineVersion = String(options.engineVersion || require('../package.json').version);
    this.packDir = path.resolve(options.packDir);
    this.host = options.host || new GamePackHost({ engineVersion: this.engineVersion, packDir: this.packDir });
    this.security = String(options.security || this.host.security || process.env.TABLETOP_PACK_SECURITY || 'signature');
    this.allowUnsigned = options.allowUnsigned === true || process.env.TABLETOP_ALLOW_UNSIGNED_PACKS === '1';
    fs.mkdirSync(this.packDir, { recursive: true });
  }
  status() {
    const games = this.host.list();
    return { engineVersion: this.engineVersion, packDir: this.packDir, games, errors: this.host.errorsSnapshot() };
  }
  install(filePath, requestedName) {
    const manifest = validateArchive(filePath, this.engineVersion, { security: this.security, allowUnsigned: this.allowUnsigned });
    const requestedFilename = sanitizeFilename(requestedName || `game-pack-${manifest.gameId}.zip`);
    const current = this.host.list().find(g => g.gameId === manifest.gameId);
    const target = current?.archive ? path.resolve(current.archive) : path.join(this.packDir, requestedFilename);
    const temp = `${target}.upload-${process.pid}-${Date.now()}`;
    const backup = `${target}.previous-${process.pid}-${Date.now()}`;
    fs.copyFileSync(filePath, temp);
    let movedBackup = false;
    try {

      // Full validation completed before replacing the live archive. Rename the
      // old target only after the new package has proven its structure/signature.
      if (fs.existsSync(target)) {
        fs.renameSync(target, backup);
        movedBackup = true;
      }
      fs.renameSync(temp, target);
      this.host.refresh();
      const loaded = this.host.get(manifest.gameId);
      if (!loaded || loaded.version !== manifest.version) throw new Error('installed-pack-not-loadable');
      const digest = sha256(target);
      if (movedBackup) fs.rmSync(backup, { force: true });
      return { action: current ? 'updated' : 'installed', manifest, archive: target, sha256: digest, status: this.status() };
    } catch (error) {
      fs.rmSync(temp, { force: true });
      fs.rmSync(target, { force: true });
      if (movedBackup && fs.existsSync(backup)) fs.renameSync(backup, target);
      try { this.host.refresh(); } catch {}
      throw error;
    }
  }
  uninstall(gameId) {
    const rec = this.host.get(gameId);
    if (rec.archive) fs.rmSync(rec.archive, { force: true });
    if (rec.root && path.basename(rec.root) !== '.installed') fs.rmSync(rec.root, { recursive: true, force: true });
    this.host.refresh();
    return { action: 'uninstalled', gameId, status: this.status() };
  }
  rescan() { this.host.refresh(); return this.status(); }
}
module.exports = { PackManager, validateArchive, sanitizeFilename };
