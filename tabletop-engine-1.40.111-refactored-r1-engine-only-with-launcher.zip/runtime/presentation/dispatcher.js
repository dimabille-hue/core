'use strict';

/**
 * Generic event-to-presentation dispatcher. It knows nothing about any game.
 * Game packages register event names to render descriptors or render callbacks.
 */
class PresentationDispatcher {
  constructor(options = {}) { this.handlers = new Map(Object.entries(options.handlers || {})); this.fallback = options.fallback || null; }
  register(eventType, handler) { if (typeof handler !== 'function' && !handler) throw new TypeError('handler-required'); this.handlers.set(String(eventType), handler); return this; }
  dispatch(events, context = {}) {
    const out = [];
    for (const event of events || []) {
      const handler = this.handlers.get(event.type) || this.fallback;
      if (!handler) continue;
      out.push(typeof handler === 'function' ? handler(event, context) : handler);
    }
    return out;
  }
}
module.exports = { PresentationDispatcher };
