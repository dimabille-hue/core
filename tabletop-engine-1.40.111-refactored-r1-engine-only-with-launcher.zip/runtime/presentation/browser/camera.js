// AUTO-GENERATED BROWSER MODULE. DO NOT EDIT.
// Source: presentation/camera.js
// Source SHA-256: cb280d10eab7fcc7f5cc4f16caa5895dbe1ec74696a1cf11d708b03020b4253c

/**
 * Generic presentation camera controller.
 * It knows only about a viewport/content pair and normalized focus coordinates.
 * It never reads or mutates game state.
 *
 * Choreography uses the Web Animations API when available, so camera motion is
 * compositor-friendly and does not require a per-frame JS loop.
 */
class PresentationCamera {
  constructor(options = {}) {
    if (!options.viewport || !options.content) throw new TypeError('camera-viewport-content-required');
    this.viewport = options.viewport;
    this.content = options.content;
    this.defaultScale = Number(options.defaultScale ?? 1);
    this.maxScale = Number(options.maxScale ?? 1.35);
    this.reducedMotion = options.reducedMotion ?? false;
    this.scale = this.defaultScale;
    this.x = 50;
    this.y = 50;
    this.animation = null;
    this.seq = 0;
  }

  setReducedMotion(value) { this.reducedMotion = !!value; }

  normalize(point = {}, scale = 1) {
    return {
      x: Math.max(0, Math.min(100, Number(point.x ?? 50))),
      y: Math.max(0, Math.min(100, Number(point.y ?? 50))),
      scale: Math.max(1, Math.min(this.maxScale, Number(scale ?? 1)))
    };
  }

  transform(point = {}) {
    const p = this.normalize(point, point.scale ?? this.scale);
    const dx = (50 - p.x) * (p.scale - 1);
    const dy = (50 - p.y) * (p.scale - 1);
    return `translate3d(${dx}%, ${dy}%, 0) scale(${p.scale})`;
  }

  focus(point = {}, options = {}) {
    this.cancel();
    const p = this.normalize(point, options.scale ?? 1.08);
    this.x = p.x;
    this.y = p.y;
    this.scale = p.scale;
    this._apply(Math.max(0, Number(options.duration ?? 520)));
  }

  reset(options = {}) {
    this.cancel();
    this.x = 50;
    this.y = 50;
    this.scale = this.defaultScale;
    this._apply(Math.max(0, Number(options.duration ?? 520)));
  }

  /**
   * Plays a short camera scene. A shot is:
   * { point:{x,y}, scale, duration, hold }
   * The returned controller can be cancelled.
   */
  choreograph(shots = [], options = {}) {
    const list = Array.isArray(shots) ? shots.filter(Boolean) : [];
    if (!list.length) return null;
    this.cancel();
    const points = list.map(shot => this.normalize(shot.point || shot, shot.scale ?? this.defaultScale));
    const duration = this.reducedMotion ? 0 : Math.max(0, Number(options.duration ?? points.reduce((sum, s) => sum + Number(s.duration ?? 420), 0)));
    const keyframes = points.map(p => ({ transform: this.transform(p) }));

    if (typeof this.content.animate === 'function' && keyframes.length > 1) {
      const animation = this.content.animate(keyframes, {
        duration,
        easing: options.easing || 'cubic-bezier(.18,.74,.22,1)',
        fill: 'both'
      });
      this.animation = animation;
      const finish = () => {
        if (this.animation === animation) {
          const last = points[points.length - 1];
          this.x = last.x; this.y = last.y; this.scale = last.scale;
          this.animation = null;
        }
      };
      animation.finished.then(finish, finish);
      return { id: ++this.seq, cancel: () => this.cancel(), animation };
    }

    const last = points[points.length - 1];
    this.x = last.x; this.y = last.y; this.scale = last.scale;
    this._apply(duration);
    return { id: ++this.seq, cancel: () => this.cancel() };
  }

  track(points = [], options = {}) {
    return this.choreograph(points, options);
  }

  cancel() {
    if (!this.animation) return;
    try { this.animation.cancel(); } catch (_) { /* noop */ }
    this.animation = null;
  }

  _apply(duration) {
    const ms = this.reducedMotion ? 0 : duration;
    this.content.style.transition = ms > 0
      ? `transform ${ms}ms cubic-bezier(.2,.8,.2,1)`
      : 'none';
    this.content.style.transformOrigin = '50% 50%';
    this.content.style.transform = this.transform(this);
  }

  destroy() {
    this.cancel();
    this.content.style.transition = '';
    this.content.style.transform = '';
    this.content.style.transformOrigin = '';
  }
}

export { PresentationCamera };
