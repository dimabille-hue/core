'use strict';

/**
 * Generic DOM presentation FX runtime.
 * It knows nothing about any game or event semantics. Game packages provide
 * compact effect descriptors; this runtime only schedules/pools visual nodes.
 */
class FxRuntime {
  constructor(root, options = {}) {
    if (!root || typeof root.appendChild !== 'function') throw new TypeError('root-required');
    this.root = root;
    this.reducedMotion = options.reducedMotion ?? false;
    this.maxActive = Math.max(1, Number(options.maxActive ?? 24));
    this.pool = [];
    this.active = new Set();
    this.seq = 0;
  }

  setReducedMotion(value) { this.reducedMotion = !!value; }

  play(descriptor = {}) {
    if (!descriptor || !descriptor.className) return null;
    this._trim();
    if (this.reducedMotion && descriptor.reducedFallback === 'none') return null;
    const node = this._acquire(descriptor);
    if (typeof node.setAttribute === 'function') node.setAttribute('class', `ls-fx ${descriptor.className}`);
    else node.className = `ls-fx ${descriptor.className}`;
    node.dataset.fxId = String(++this.seq);
    if (descriptor.label) node.setAttribute('aria-label', descriptor.label);
    const style = descriptor.style || {};
    for (const [key, value] of Object.entries(style)) node.style.setProperty(key, String(value));
    if (descriptor.text) node.textContent = descriptor.text;
    this.root.appendChild(node);
    this.active.add(node);
    const duration = this.reducedMotion ? 40 : Math.max(20, Number(descriptor.duration ?? 650));
    const cleanup = () => this._release(node);
    const keyframes = descriptor.keyframes || this._motionKeyframes(descriptor);
    if (typeof node.animate === 'function' && keyframes) {
      const animation = node.animate(keyframes, { duration, easing: descriptor.easing || 'cubic-bezier(.2,.8,.2,1)', fill: 'both' });
      animation.finished.then(cleanup, cleanup);
    } else {
      const timer = setTimeout(cleanup, duration);
      node.__lsFxTimer = timer;
    }
    return node;
  }

  clear() {
    for (const node of Array.from(this.active)) this._release(node);
    for (const node of this.pool) node.remove();
    this.pool.length = 0;
  }

  _acquire(descriptor = {}) {
    const factory = typeof descriptor.nodeFactory === 'function' ? descriptor.nodeFactory : null;
    const node = factory ? factory(this.root.ownerDocument) : (this.pool.pop() || this.root.ownerDocument.createElement('div'));
    if (node) node.__lsFxFactoryNode = !!factory;
    if (factory) {
      while (this.pool.length && !node) this.pool.pop();
    }
    node.removeAttribute('aria-label');
    node.textContent = '';
    node.style.cssText = '';
    return node;
  }

  _motionKeyframes(descriptor) {
    const from = descriptor.from;
    const to = descriptor.to;
    if (!from || !to) return null;
    const fx = Number(from.x ?? 50), fy = Number(from.y ?? 50);
    const tx = Number(to.x ?? fx), ty = Number(to.y ?? fy);
    const rect = typeof this.root.getBoundingClientRect === 'function' ? this.root.getBoundingClientRect() : null;
    const width = Math.max(1, Number(rect?.width || 100));
    const height = Math.max(1, Number(rect?.height || 100));
    const x1 = width * fx / 100;
    const y1 = height * fy / 100;
    const x2 = width * tx / 100;
    const y2 = height * ty / 100;
    const angle = descriptor.rotate === false ? 0 : Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
    return [
      { opacity: Number(descriptor.startOpacity ?? 0), transform: `translate3d(${x1}px,${y1}px,0) translate(-50%,-50%) rotate(${angle}deg) scale(${descriptor.startScale ?? .82})` },
      { opacity: Number(descriptor.peakOpacity ?? 1), transform: `translate3d(${x2}px,${y2}px,0) translate(-50%,-50%) rotate(${angle}deg) scale(${descriptor.endScale ?? 1})` }
    ];
  }

  _release(node) {
    if (!node || !this.active.has(node)) return;
    this.active.delete(node);
    if (node.__lsFxTimer) clearTimeout(node.__lsFxTimer);
    node.__lsFxTimer = null;
    if (typeof node.setAttribute === 'function') node.setAttribute('class', '');
    else node.className = '';
    node.textContent = '';
    node.style.cssText = '';
    node.removeAttribute('aria-label');
    node.remove();
    if (!node.__lsFxFactoryNode && this.pool.length < this.maxActive) this.pool.push(node);
    delete node.__lsFxFactoryNode;
  }

  _trim() {
    if (this.active.size < this.maxActive) return;
    const oldest = this.active.values().next().value;
    if (oldest) this._release(oldest);
  }
}

module.exports = { FxRuntime };
