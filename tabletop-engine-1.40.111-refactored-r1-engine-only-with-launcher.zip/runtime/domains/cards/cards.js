'use strict';

const { assert } = require('../../core/errors');

function cloneCard(card) {
  return card && typeof card === 'object' ? { ...card } : card;
}

function makeCards(specs, prefix = 'card') {
  const out = [];
  let serial = 1;
  for (const spec of specs || []) {
    const count = Math.max(0, Number(spec.count ?? 1) | 0);
    for (let i = 0; i < count; i++) {
      const card = typeof spec.create === 'function' ? spec.create(i, serial) : { ...spec, count: undefined, create: undefined };
      delete card.count;
      delete card.create;
      if (!card.id) card.id = `${prefix}:${serial}`;
      out.push(Object.freeze(cloneCard(card)));
      serial++;
    }
  }
  return out;
}

class CardRegistry {
  constructor(definitions = {}) { this.definitions = new Map(Object.entries(definitions)); }
  get(type) { return this.definitions.get(type) || null; }
  require(type) { const d = this.get(type); assert(d, 'unknown-card-type', `Unknown card type: ${type}`); return d; }
  register(type, definition) { assert(!this.definitions.has(type), 'card-type-exists'); this.definitions.set(type, definition); return definition; }
}

module.exports = { cloneCard, makeCards, CardRegistry };
