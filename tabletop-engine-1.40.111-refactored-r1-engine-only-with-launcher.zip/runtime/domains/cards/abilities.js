'use strict';

const { assert } = require('../../core/errors');

function clone(value) {
  if (typeof structuredClone === 'function') return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function defineAbility(id, spec = {}) {
  assert(typeof id === 'string' && id.length > 0, 'invalid-ability-id');
  return Object.freeze({
    id,
    name: spec.name ?? id,
    text: spec.text ?? null,
    condition: spec.condition ?? null,
    cost: spec.cost ?? null,
    cooldown: Math.max(0, Number(spec.cooldown || 0) | 0),
    uses: spec.uses == null ? null : Math.max(0, Number(spec.uses) | 0),
    target: spec.target ?? null,
    effects: spec.effects ?? [],
    metadata: clone(spec.metadata || {})
  });
}

class AbilityBook {
  constructor(state, definitions = {}) {
    this.state = state;
    this.definitions = new Map(Object.entries(definitions));
    this.state.abilities ||= {};
  }

  register(ability) {
    const definition = ability.id ? ability : defineAbility(ability.type || ability.id, ability);
    assert(!this.definitions.has(definition.id), 'ability-exists');
    this.definitions.set(definition.id, definition);
    return definition;
  }

  get(id) { return this.definitions.get(id) || null; }
  require(id) { const d = this.get(id); assert(d, 'unknown-ability', `Unknown ability: ${id}`); return d; }

  ensurePlayer(player) {
    this.state.abilities[player] ||= {};
    for (const [id, def] of this.definitions) {
      this.state.abilities[player][id] ||= { usesLeft: def.uses, readyAtTurn: 0 };
    }
    return this.state.abilities[player];
  }

  status(player, id) {
    const def = this.require(id);
    this.ensurePlayer(player);
    return { ...this.state.abilities[player][id], id, ready: this.ready(player, id) };
  }

  ready(player, id, turn = null) {
    const def = this.require(id);
    const currentTurn = turn ?? this.state.turn ?? 0;
    const s = this.ensurePlayer(player)[id];
    return (s.usesLeft == null || s.usesLeft > 0) && currentTurn >= (s.readyAtTurn || 0);
  }

  consume(player, id, turn = null) {
    const def = this.require(id);
    assert(this.ready(player, id, turn), 'ability-not-ready');
    const s = this.ensurePlayer(player)[id];
    if (s.usesLeft != null) s.usesLeft -= 1;
    const currentTurn = turn ?? this.state.turn ?? 0;
    s.readyAtTurn = currentTurn + def.cooldown;
    return { ...s };
  }

  snapshot(player) {
    this.ensurePlayer(player);
    const out = {};
    for (const id of this.definitions.keys()) out[id] = this.status(player, id);
    return out;
  }
}

function compileAbilityActions(definitions, options = {}) {
  const normalized = (definitions || []).map(d => d.id ? d : defineAbility(d.type, d));
  const map = new Map(normalized.map(d => [d.id, d]));
  const command = options.command || 'USE_ABILITY';

  function materialize(value, ctx, ability, input) {
    return typeof value === 'function' ? value(ctx, ability, input) : clone(value);
  }

  return {
    abilities: map,
    command,
    actions: {
      [command](ctx, cmd) {
        assert(typeof cmd?.abilityId === 'string', 'ability-id-required');
        const ability = map.get(cmd.abilityId);
        assert(ability, 'unknown-ability');
        const book = new AbilityBook(ctx.state, Object.fromEntries(map));
        book.ensurePlayer(ctx.actor);
        assert(book.ready(ctx.actor, ability.id, ctx.turn), 'ability-not-ready');
        const condition = materialize(ability.condition, ctx, ability, cmd);
        assert(condition !== false, `ability-condition-failed:${ability.id}`);

        if (ability.cost && options.resources) options.resources.spend(ctx.actor, materialize(ability.cost, ctx, ability, cmd));
        book.consume(ctx.actor, ability.id, ctx.turn);

        let targets = [];
        if (ability.target != null) {
          const target = materialize(ability.target, ctx, ability, cmd);
          targets = Array.isArray(target) ? target.slice() : [target];
        }
        const effects = [];
        for (const item of Array.isArray(ability.effects) ? ability.effects : [ability.effects]) {
          const value = materialize(item, ctx, ability, { ...cmd, targets });
          if (value) effects.push(...(Array.isArray(value) ? value : [value]));
        }
        ctx.pushEffects(effects);
        ctx.emit('ABILITY_USED', { player: ctx.actor, ability: ability.id, targets }, options.audience ?? null);
        return { abilityId: ability.id, targets };
      }
    }
  };
}

module.exports = { defineAbility, AbilityBook, compileAbilityActions };
