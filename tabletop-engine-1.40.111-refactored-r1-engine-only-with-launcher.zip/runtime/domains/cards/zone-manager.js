'use strict';

const { assert } = require('../../core/errors');
const { Zone } = require('./zones');

class ZoneManager {
  constructor(state, random) {
    this.state = state;
    this.random = random;
    this.state.zones ||= {};
  }

  define(id, spec = {}) {
    assert(typeof id === 'string' && id.length > 0, 'invalid-zone-id');
    const existing = this.state.zones[id];
    if (existing) return this._runtime(existing);
    const zone = {
      id,
      cards: [],
      kind: spec.kind || 'stack',
      owner: spec.owner ?? null,
      visibility: spec.visibility || 'public',
      faceUp: spec.faceUp !== false,
      capacity: Number.isFinite(spec.capacity) ? Math.max(0, Math.trunc(spec.capacity)) : null,
      metadata: { ...(spec.metadata || {}) }
    };
    this.state.zones[id] = zone;
    return this._runtime(zone);
  }

  get(id) { return this.state.zones[id] ? this._runtime(this.state.zones[id]) : null; }
  require(id) { const zone = this.get(id); assert(zone, 'unknown-zone', `Unknown zone: ${id}`); return zone; }

  move(cardId, fromId, toId) {
    const from = this.require(fromId); const to = this.require(toId);
    const card = from.remove(cardId);
    assert(card, 'card-not-found');
    to.push(card);
    return card;
  }

  visible(id, viewer = null) {
    const z = this.require(id).zone;
    const privateToOwner = z.visibility === 'owner' && z.owner !== viewer;
    const hidden = z.visibility === 'hidden' || privateToOwner;
    return {
      id: z.id,
      kind: z.kind,
      owner: z.owner,
      count: z.cards.length,
      cards: hidden ? null : z.cards.map(c => ({ ...c }))
    };
  }

  allVisible(viewer = null) {
    const out = {};
    for (const id of Object.keys(this.state.zones)) out[id] = this.visible(id, viewer);
    return out;
  }

  _runtime(zone) { return new Zone(zone.id, zone, { random: this.random }); }
}

module.exports = { ZoneManager };
