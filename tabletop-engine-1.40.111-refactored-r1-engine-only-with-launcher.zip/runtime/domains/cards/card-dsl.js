'use strict';

const { assert } = require('../../core/errors');
const { CardTable } = require('./card-table');

const SKIP = Symbol('CARD_DSL_SKIP');

function clone(value) {
  if (typeof structuredClone === 'function') return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function asList(value) { return value == null ? [] : (Array.isArray(value) ? value : [value]); }

function defineCard(type, spec = {}) {
  assert(typeof type === 'string' && type.length > 0, 'invalid-card-type');
  assert(spec && typeof spec === 'object', 'invalid-card-definition');
  return Object.freeze({
    type,
    name: spec.name ?? type,
    text: spec.text ?? null,
    tags: Object.freeze([...(spec.tags || [])]),
    cost: spec.cost ?? null,
    condition: spec.condition ?? null,
    target: spec.target ?? null,
    effects: spec.effects ?? [],
    reactions: spec.reactions ?? null,
    aftermath: spec.aftermath ?? null,
    playTo: spec.playTo === false ? false : (spec.playTo || null),
    metadata: clone(spec.metadata || {})
  });
}

function compileCardActions(cardDefinitions, options = {}) {
  const cards = new Map();
  for (const card of cardDefinitions || []) {
    const definition = card.type ? card : defineCard(card.id || card.type, card);
    assert(!cards.has(definition.type), 'card-type-exists');
    cards.set(definition.type, definition);
  }

  const playCommand = options.command || 'PLAY_CARD';
  const handOf = options.handOf || (player => `hand:${player}`);

  function getCard(ctx, player, cardId) {
    const table = new CardTable(ctx, options.table || {});
    const hand = table.hand(player);
    const index = hand.cards.findIndex(c => c?.id === cardId);
    assert(index >= 0, 'card-not-in-hand');
    return { table, hand, card: hand.cards[index], index };
  }

  function makePlayEffect(card, player, command) {
    return { type: '__PLAY_CARD__', actor: player, card: clone(card), command: clone(command) };
  }

  function materialize(value, ctx, play) {
    if (typeof value === 'function') return value(ctx, play);
    return clone(value);
  }

  function resolveTargets(targetSpec, ctx, play) {
    if (targetSpec == null) return [play.actor];
    const spec = materialize(targetSpec, ctx, play);
    if (typeof spec === 'string') return [spec];
    if (Array.isArray(spec)) return spec.slice();
    if (spec && spec.type) {
      switch (spec.type) {
        case 'self': return [play.actor];
        case 'active': return [ctx.active];
        case 'player': return [spec.player ?? spec.id];
        case 'others': return [...ctx.players.keys()].filter(id => id !== play.actor);
        case 'all': return [...ctx.players.keys()];
        case 'next': {
          const ids = ctx.engine?.active ? ctx.engine.players : ctx.players;
          const list = [...ids.keys()];
          const i = list.indexOf(play.actor);
          return list.length ? [list[(i + 1) % list.length]] : [];
        }
        case 'choose': {
          const rawOptions = typeof spec.players === 'function' ? spec.players(ctx, play) : spec.players;
          const options = (rawOptions || [...ctx.players.keys()]).filter(Boolean);
          ctx.choose({
            type: spec.choiceType || 'SELECT_TARGET',
            player: play.actor,
            options,
            data: spec.data || null,
            public: spec.public !== false,
            commands: spec.commands || ['CHOOSE']
          });
          return [SKIP];
        }
        default: throw new Error(`unknown-target-type:${spec.type}`);
      }
    }
    return [spec];
  }

  function resolveEffectTemplates(templates, ctx, play, targets) {
    const out = [];
    for (const item of asList(templates)) {
      const values = typeof item === 'function' ? asList(item(ctx, play, targets)) : [item];
      for (const value of values) {
        if (!value) continue;
        const effect = clone(value);
        if (effect.target === '$target') effect.target = targets[0];
        if (effect.targets === '$targets') effect.targets = targets.slice();
        if (effect.actor === '$actor') effect.actor = play.actor;
        if (effect.cardId === '$cardId') effect.cardId = play.card.id;
        if (effect.cardType === '$cardType') effect.cardType = play.card.type;
        out.push(effect);
      }
    }
    return out;
  }

  function resolveCost(cost, ctx, play) {
    if (cost == null) return [];
    const root = typeof cost === 'function' ? cost(ctx, play) : cost;
    const list = asList(root);
    const out = [];
    for (const item of list) {
      if (!item) continue;
      if (item && typeof item.__cardCost === 'function') {
        out.push(...asList(item.__cardCost(ctx, play)));
      } else {
        out.push(clone(item));
      }
    }
    return out.filter(Boolean);
  }

  const effects = {
    __PLAY_CARD__(ctx, effect) {
      const card = cards.get(effect.card.type);
      assert(card, 'unknown-card-type');
      const play = {
        actor: effect.actor,
        card: clone(effect.card),
        command: clone(effect.command),
        targets: [],
        args: clone(effect.command?.args || {})
      };

      const table = new CardTable(ctx, options.table || {});
      const hand = table.hand(play.actor);
      const liveCard = hand.cards.find(c => c?.id === play.card.id);
      assert(liveCard, 'card-not-in-hand');
      play.card = liveCard;

      const condition = materialize(card.condition, ctx, play);
      assert(condition !== false, `card-condition-failed:${card.type}`);

      hand.remove(play.card.id);
      const destination = card.playTo === false ? null : (card.playTo || options.playTo || 'discard');
      if (destination) table.discard(destination).push(play.card);

      const targetResult = resolveTargets(card.target, ctx, play);
      if (targetResult.some(x => x === SKIP)) {
        ctx.state.cardDslPending = {
          cardType: card.type,
          card: clone(play.card),
          actor: play.actor,
          command: clone(play.command)
        };
        return;
      }
      play.targets = targetResult.filter(Boolean);

      const cost = resolveCost(card.cost, ctx, play);
      const body = resolveEffectTemplates(card.effects, ctx, play, play.targets);
      const aftermath = resolveEffectTemplates(card.aftermath, ctx, play, play.targets);
      const resolveEffect = {
        type: '__CARD_RESOLVE__',
        actor: play.actor,
        card: clone(play.card),
        cardType: card.type,
        targets: play.targets,
        command: clone(play.command),
        body,
        aftermath,
        beforeReaction: card.reactions?.before ? clone(materialize(card.reactions.before, ctx, play)) : null,
        cancelAsNoop: card.reactions?.cancelAsNoop !== false
      };

      const sequence = [...cost, resolveEffect];
      ctx.emit('CARD_PLAYED', {
        player: play.actor,
        card: play.card.type,
        cardId: play.card.id,
        targets: play.targets
      }, options.cardPlayedAudience ?? null);
      return sequence.length ? { effects: sequence } : null;
    },

    __CARD_RESOLVE__(ctx, effect) {
      if (effect.beforeReaction) {
        ctx.reaction({
          ...effect.beforeReaction,
          cancelOn: effect.beforeReaction.cancelOn || null,
          resume: { effect: { type: '__CARD_AFTER_REACTION__', payload: clone(effect) } }
        });
        return;
      }
      ctx.pushEffects([...(effect.body || []), ...(effect.aftermath || [])]);
    },

    __CARD_AFTER_REACTION__(ctx, effect) {
      const payload = effect.payload || {};
      ctx.pushEffects([...(payload.body || []), ...(payload.aftermath || [])]);
    },

    ...options.effects
  };

  const actions = {
    [playCommand](ctx, command) {
      assert(command && typeof command.cardId === 'string', 'card-id-required');
      const { card } = getCard(ctx, ctx.actor, command.cardId);
      const definition = cards.get(card.type);
      assert(definition, 'unknown-card-type');
      ctx.pushEffect(makePlayEffect(card, ctx.actor, command));
      return { cardId: card.id, cardType: card.type };
    }
  };

  function resolveChoice(ctx, pending, command) {
    const data = pending?.data?.cardDsl || ctx.state.cardDslPending;
    if (!data || (pending.type !== 'SELECT_TARGET' && pending.type !== 'SELECT_PLAYER')) return false;
    assert(typeof command.value === 'string', 'invalid-target');
    assert(ctx.players.has(command.value), 'invalid-target');
    const card = cards.get(data.cardType);
    assert(card, 'unknown-card-type');
    const play = {
      actor: data.actor,
      card: clone(data.card),
      command: clone(data.command),
      targets: [command.value],
      args: clone(data.command?.args || {})
    };
    delete ctx.state.cardDslPending;

    const cost = resolveCost(card.cost, ctx, play);
    const body = resolveEffectTemplates(card.effects, ctx, play, play.targets);
    const aftermath = resolveEffectTemplates(card.aftermath, ctx, play, play.targets);
    const resolveEffect = {
      type: '__CARD_RESOLVE__',
      actor: play.actor,
      card: clone(play.card),
      cardType: card.type,
      targets: play.targets,
      command: clone(play.command),
      body,
      aftermath,
      beforeReaction: card.reactions?.before ? clone(materialize(card.reactions.before, ctx, play)) : null,
      cancelAsNoop: card.reactions?.cancelAsNoop !== false
    };
    ctx.pushEffects([...cost, resolveEffect]);
    ctx.emit('CARD_TARGET_SELECTED', {
      player: play.actor,
      card: play.card.type,
      cardId: play.card.id,
      target: command.value
    }, options.cardPlayedAudience ?? null);
    return true;
  }


  return {
    cards,
    actions,
    effects,
    playCommand,
    handOf,
    getCard,
    resolveChoice,
    SKIP
  };
}

function projectDeclaredState(state, paths) {
  if (!Array.isArray(paths) || !paths.length) return undefined;
  const out = {};
  for (const path of paths) {
    const parts = String(path).split('.').filter(Boolean);
    let source = state;
    for (const part of parts) { if (source == null) break; source = source[part]; }
    if (source === undefined) continue;
    let target = out;
    for (let i = 0; i < parts.length - 1; i++) { target[parts[i]] ||= {}; target = target[parts[i]]; }
    target[parts.at(-1)] = clone(source);
  }
  return out;
}

function composeCardDefinition(baseDefinition, cardDefinitions, options = {}) {
  const compiled = compileCardActions(cardDefinitions, options);
  const base = baseDefinition || {};
  const baseProject = base.project;
  const project = baseProject || ((state, viewer, snapshot) => {
    if (options.legacyPublicState === true) return { ...snapshot, state };
    const declared = projectDeclaredState(state, options.publicStatePaths);
    return declared === undefined ? { ...snapshot } : { ...snapshot, state: declared };
  });
  return {
    ...base,
    id: options.id || base.id,
    actions: { ...(base.actions || {}), ...compiled.actions },
    effects: { ...(base.effects || {}), ...compiled.effects },
    project,
    resolveChoice(ctx, pending, command) {
      const handled = compiled.resolveChoice(ctx, pending, command);
      if (handled) return;
      if (typeof base.resolveChoice === 'function') return base.resolveChoice(ctx, pending, command);
      throw new Error('unhandled-choice');
    }
  };
}

const conditions = {
  all: (...tests) => ctx => tests.every(test => !!runTest(test, ctx)),
  any: (...tests) => ctx => tests.some(test => !!runTest(test, ctx)),
  not: test => ctx => !runTest(test, ctx),
  phase: phase => ctx => ctx.phase === phase,
  active: player => ctx => ctx.active === player,
  playerCount: count => ctx => ctx.players.size === count,
  minPlayers: count => ctx => ctx.players.size >= count,
  hasCard: (player, type) => ctx => {
    const hand = new CardTable(ctx).hand(player).cards;
    return hand.some(card => card?.type === type);
  },
  state: (path, expected) => ctx => getPath(ctx.state, path) === expected,
  predicate: fn => fn
};

function runTest(test, ctx) { return typeof test === 'function' ? test(ctx) : !!test; }
function getPath(root, path) { return String(path).split('.').reduce((value, key) => value == null ? undefined : value[key], root); }

const targets = Object.freeze({
  self: () => ({ type: 'self' }),
  active: () => ({ type: 'active' }),
  player: id => ({ type: 'player', id }),
  others: () => ({ type: 'others' }),
  all: () => ({ type: 'all' }),
  choosePlayer: (options, data = null) => ({ type: 'choose', players: options, data }),
  next: () => ({ type: 'next' })
});

const effects = Object.freeze({
  effect: (type, args = []) => ({ type, args: Array.isArray(args) ? args.slice() : [args] }),
  dynamic: fn => fn,
  to: (effect, target) => ({ ...clone(effect), target }),
  targetAll: effect => ({ ...clone(effect), targets: '$targets' }),
  actor: effect => ({ ...clone(effect), actor: '$actor' })
});

const costs = Object.freeze({
  effect: (type, args = []) => ({ type, args: Array.isArray(args) ? args.slice() : [args] }),
  dynamic: fn => ({ __cardCost: fn }),
  sequence: (...items) => items.flatMap(asList)
});

function getCardDefinition(registry, type) {
  if (registry instanceof Map) return registry.get(type) || null;
  return registry?.[type] || null;
}

module.exports = {
  defineCard,
  compileCardActions,
  conditions,
  targets,
  effects,
  costs,
  getCardDefinition,
  composeCardDefinition
};
