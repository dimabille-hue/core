'use strict';

function shuffle(a, random) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = (random() * (i + 1)) | 0;
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function makeDeck(cards, random) {
  return shuffle(cards.slice(), random);
}

function draw(zone) {
  return zone.length ? zone.pop() : null;
}

module.exports = { shuffle, makeDeck, draw };
