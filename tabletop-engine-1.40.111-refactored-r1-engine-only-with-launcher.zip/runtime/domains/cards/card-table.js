'use strict';

const { Zone } = require('./zones');
const { makeCards } = require('./cards');
const { assert } = require('../../core/errors');

// Compact card-game facade over the engine's canonical Zone abstraction.
// It stores only plain serializable data in ctx.state.
class CardTable {
  constructor(ctx, options = {}) {
    this.ctx = ctx;
    this.state = ctx.state;
    this.prefix = options.prefix || 'card';
    this.state.zones ||= {};
    this.state.hands ||= {};
    this.state.cardSerial ||= 1;
  }

  zone(id, spec = {}) {
    const z = this.state.zones[id] ||= {
      id,
      cards: [],
      kind: spec.kind || 'stack',
      owner: spec.owner ?? null,
      visibility: spec.visibility || 'public',
      faceUp: spec.faceUp !== false,
      capacity: Number.isFinite(spec.capacity) ? Math.max(0, Math.trunc(spec.capacity)) : null,
      metadata: { ...(spec.metadata || {}) }
    };
    return this.runtime(z);
  }

  deck(id, cards = [], shuffle = true) {
    const z = this.state.zones[id] ||= { id, cards: [], kind: 'deck', visibility: 'hidden', owner: null, faceUp: false, capacity: null, metadata: {} };
    if (!Array.isArray(z.cards)) z.cards = [];
    if (z.cards.length === 0 && cards.length) z.cards = cards.slice();
    const deck = this.runtime(z);
    if (shuffle) deck.shuffle();
    return deck;
  }

  discard(id = 'discard') { return this.zone(id, { kind: 'discard', visibility: 'public', faceUp: true }); }

  hand(player) {
    assert(this.ctx.players.has(player), 'unknown-player');
    const z = this.state.hands[player] ||= [];
    return new Zone(`hand:${player}`, { id: `hand:${player}`, cards: z }, { random: this.ctx.random });
  }

  deal(deck, player, count = 1) {
    const hand = this.hand(player);
    const cards = deck.draw(count);
    hand.pushMany(cards);
    return cards;
  }

  createCards(specs) {
    const prefix = `${this.prefix}:${this.state.cardSerial++}`;
    return makeCards(specs, prefix);
  }

  move(cardId, from, to) {
    const card = from.remove(cardId);
    assert(card, 'card-not-found');
    to.push(card);
    return card;
  }

  runtime(zone) {
    return new Zone(zone.id, zone, { random: this.ctx.random });
  }
}

// Kept as a compatibility alias. New code should import Zone.
const RuntimeZone = Zone;

module.exports = { CardTable, RuntimeZone };
