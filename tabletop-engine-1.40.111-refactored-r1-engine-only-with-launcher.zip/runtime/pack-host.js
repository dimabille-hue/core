'use strict';
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const {extractZip,readEntries,readEntry}=require('./zip-reader');
const {verifyPack}=require('./pack-signature');

const DEFAULT_PACK_DIR=()=>{
  if(process.env.TABLETOP_GAME_PACKS_DIR) return path.resolve(process.env.TABLETOP_GAME_PACKS_DIR);
  if(process.env.TABLETOP_DATA_DIR) return path.resolve(process.env.TABLETOP_DATA_DIR,'game-packs');
  const engineRoot=path.resolve(__dirname,'..');
  const installPacks=path.join(engineRoot,'game-packs');
  const sourceGames=path.join(engineRoot,'games');
  try { const pkg=JSON.parse(fs.readFileSync(path.join(engineRoot,'package.json'),'utf8')); if(pkg.private && fs.existsSync(sourceGames)) return sourceGames; } catch {}
  return installPacks;
};
function safeId(v){return typeof v==='string' && /^[a-z0-9][a-z0-9-]{0,63}$/.test(v);}
function parseVersion(v){const m=String(v||'').match(/^(\d+)\.(\d+)(?:\.(\d+))?/);return m?{major:+m[1],minor:+m[2],patch:+(m[3]||0)}:null;}
function compatible(range,engineVersion){
  if(!range) return true;
  const ev=parseVersion(engineVersion); if(!ev) return false;
  const exact=String(range).trim();
  if(exact==='1.40.x') return ev.major===1&&ev.minor===40;
  const parts=exact.split(/\s+/).filter(Boolean);
  for(const p of parts){
    const m=p.match(/^(>=|>|<=|<|=)?(\d+)\.(\d+)(?:\.(\d+))?/); if(!m) continue;
    const op=m[1]||'='; const v={major:+m[2],minor:+m[3],patch:+(m[4]||0)};
    const a=ev.major*1e6+ev.minor*1e3+ev.patch,b=v.major*1e6+v.minor*1e3+v.patch;
    if(op==='>'&&!(a>b)||op==='>='&&!(a>=b)||op==='<'&&!(a<b)||op==='<='&&!(a<=b)||op==='='&&!(a===b)) return false;
  }
  return true;
}
class GamePackHost{
 constructor(options={}){
  this.engineVersion=String(options.engineVersion||require('../package.json').version);
  this.packDir=path.resolve(options.packDir||DEFAULT_PACK_DIR());
  this.cacheDir=path.resolve(options.cacheDir||path.join(this.packDir,'.installed'));
  this.records=new Map(); this.errors=[];
  this.security=String(options.security||process.env.TABLETOP_PACK_SECURITY||'signature');
  this.allowUnsigned=options.allowUnsigned===true || process.env.TABLETOP_ALLOW_UNSIGNED_PACKS==='1';
 }
 refresh(){
  this.records.clear(); this.errors=[];
  fs.mkdirSync(this.packDir,{recursive:true}); fs.mkdirSync(this.cacheDir,{recursive:true});
  for(const name of fs.readdirSync(this.packDir).sort()){
   if(name.startsWith('.')) continue;
   const full=path.join(this.packDir,name);
   try{
    let root=full, source='directory', archive=null;
    const st=fs.statSync(full);
    if(st.isFile() && name.toLowerCase().endsWith('.zip')){
      const entries=readEntries(full);
      const manifestEntry=entries.get('manifest.json');
      if(!manifestEntry) throw new Error('missing-manifest');
      const manifestBuffer=readEntry(manifestEntry);
      const manifest=JSON.parse(manifestBuffer.toString('utf8'));
      validateManifest(manifest,{distribution:true});
      if(this.security==='signature' && !this.allowUnsigned){
        const buffers=[]; for(const [entryName,entry] of entries) buffers.push([entryName,readEntry(entry)]);
        const verification=verifyPack(manifest,buffers);
        if(!verification.ok) throw new Error(`invalid-pack-signature:${verification.reason}`);
      }
      if(!compatible(manifest.engineCompatibility,this.engineVersion)) throw new Error(`incompatible-engine:${manifest.engineCompatibility}`);
      const sourceSha256=sha256File(full);
      const signature=`${sourceSha256}:${manifest.gameId}:${manifest.version}`;
      const cacheName=`${manifest.gameId}@${String(manifest.version).replace(/[^A-Za-z0-9._-]/g,'_')}~${sourceSha256.slice(0,16)}`;
      const cacheRoot=path.join(this.cacheDir,cacheName), stamp=path.join(cacheRoot,'.source-signature');
      if(!fs.existsSync(path.join(cacheRoot,'manifest.json')) || !fs.existsSync(stamp) || fs.readFileSync(stamp,'utf8')!==signature){
        const temp=fs.mkdtempSync(path.join(this.cacheDir,'extract-'));
        try { extractZip(full,temp); const extractedRoot=fs.existsSync(path.join(temp,'manifest.json'))?temp:findSingleRoot(temp); fs.rmSync(cacheRoot,{recursive:true,force:true}); fs.renameSync(extractedRoot,cacheRoot); fs.rmSync(temp,{recursive:true,force:true}); }
        catch(e){fs.rmSync(temp,{recursive:true,force:true});throw e;}
        fs.writeFileSync(stamp,signature);
      }
      root=cacheRoot; source='zip'; archive=full;
    } else if(!st.isDirectory()) continue;
    const manifest=readManifest(root,{distribution:source==='zip'});
    if(!compatible(manifest.engineCompatibility,this.engineVersion)) throw new Error(`incompatible-engine:${manifest.engineCompatibility}`);
    if(this.records.has(manifest.gameId)) throw new Error(`duplicate-game-id:${manifest.gameId}`);
    const rec={...manifest,root,source,archive};
    this.records.set(manifest.gameId,rec);
   }catch(e){this.errors.push({file:name,error:e.message||String(e)});}
  }
 }
 list(){this.refresh(); return [...this.records.values()].map(({root,archive,...m})=>({...m}));}
 get(id){this.refresh(); const rec=this.records.get(String(id)); if(!rec) throw new Error('unknown-game-pack'); return {...rec};}
 resolveFile(id,relative){const r=this.get(id); const clean=String(relative||'').replace(/^\/+/, ''); if(!isPublicPackPath(clean,r)) throw new Error('pack-file-not-public'); const file=path.resolve(r.root,clean); if(!file.startsWith(path.resolve(r.root)+path.sep)) throw new Error('pack-path-escape'); if(!fs.existsSync(file)) throw new Error('pack-file-not-found'); return file;}
 load(id){const r=this.get(id);
  if(r.source==='zip' && this.security==='signature' && !this.allowUnsigned){
    const buffers=[]; for(const file of walkFiles(r.root)) buffers.push([file.path,fs.readFileSync(file.abs)]);
    const signedManifest={...r}; delete signedManifest.root; delete signedManifest.archive; delete signedManifest.source;
    const verification=verifyPack(signedManifest, buffers); if(!verification.ok) throw new Error(`pack-integrity-failed:${verification.reason}`);
  }
  const prev=process.env.TABLETOP_ENGINE_API_ROOT; process.env.TABLETOP_ENGINE_API_ROOT=__dirname;
  try{const mod=require(path.resolve(r.root,r.entry)); const manifest={...r}; delete manifest.root; delete manifest.archive; return {manifest,definition:mod,root:r.root};}
  finally{if(prev==null) delete process.env.TABLETOP_ENGINE_API_ROOT;}
 }
 errorsSnapshot(){return this.errors.slice();}
}
function validateManifest(m,{distribution=false}={}){
 if(!m) throw new Error('unsupported-pack-schema');
 if(distribution && m.schemaVersion!==1) throw new Error('unsupported-pack-schema');
 if(distribution&&m.packFormatVersion!==1) throw new Error('unsupported-pack-schema');
 if(!safeId(m.gameId)) throw new Error('invalid-game-id');
 if(!m.name||!m.version||!m.entry) throw new Error('invalid-manifest');
 if(!m.capabilities||!Array.isArray(m.capabilities)) throw new Error('missing-capabilities');
 if(m.publicPaths!=null && (!Array.isArray(m.publicPaths) || m.publicPaths.some(v=>typeof v!=='string' || !v || v.startsWith('/') || v.includes('..')))) throw new Error('invalid-public-paths');
}
function readManifest(root,{distribution=false}={}){
 const file=path.join(root,'manifest.json');
 if(!fs.existsSync(file)) throw new Error('missing-manifest');
 const m=JSON.parse(fs.readFileSync(file,'utf8')); validateManifest(m,{distribution});
 if(!fs.existsSync(path.join(root,m.entry))) throw new Error('missing-entry');
 if(!fs.existsSync(path.join(root,'preview','index.html'))) throw new Error('missing-preview');
 if(m.capabilities.includes('player')&&!fs.existsSync(path.join(root,'player-ui','index.html'))) throw new Error('missing-player-surface');
 if(m.capabilities.includes('tv')&&!fs.existsSync(path.join(root,'tv-ui','index.html'))) throw new Error('missing-tv-surface');
 return m;
}

function sha256File(file){ const h= require('node:crypto').createHash('sha256'); h.update(fs.readFileSync(file)); return h.digest('hex'); }
function isPublicPackPath(relative, manifest){
 const rel=String(relative||'').replace(/^\/+/, '').replace(/\\/g,'/');
 const declared=Array.isArray(manifest?.publicPaths)?manifest.publicPaths.map(String):[];
 if(declared.length) return declared.some(prefix=>rel===prefix || rel.startsWith(prefix.replace(/\/+$/,'')+'/'));
 return ['preview/','player-ui/','tv-ui/','assets/','public/'].some(prefix=>rel.startsWith(prefix));
}
function walkFiles(root){
 const out=[];
 function visit(dir,base=''){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const abs=path.join(dir,e.name),rel=base?base+'/'+e.name:e.name;if(e.isDirectory())visit(abs,rel);else if(e.isFile() && !rel.startsWith('.'))out.push({path:rel,abs});}}
 visit(root); return out;
}
function findSingleRoot(temp){
 const entries=fs.readdirSync(temp,{withFileTypes:true});
 if(entries.length===1&&entries[0].isDirectory()&&fs.existsSync(path.join(temp,entries[0].name,'manifest.json'))) return path.join(temp,entries[0].name);
 return temp;
}
module.exports={GamePackHost,DEFAULT_PACK_DIR,compatible,isPublicPackPath,validateManifest};
