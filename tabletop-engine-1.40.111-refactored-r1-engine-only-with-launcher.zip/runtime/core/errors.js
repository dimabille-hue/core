'use strict';

class GameError extends Error {
  constructor(code, message = code, meta = null) {
    super(message);
    this.name = 'GameError';
    this.code = code;
    this.meta = meta;
  }
}

function fail(code, message, meta) {
  throw new GameError(code, message, meta);
}

function assert(ok, code, message, meta) {
  if (!ok) fail(code, message, meta);
}

module.exports = { GameError, fail, assert };
