'use strict';

const { assert } = require('./errors');

/**
 * LIFO effect stack. `pushMany([A,B])` keeps the intuitive execution order A -> B
 * while still allowing an interrupt to push a new effect on top of the stack.
 */
class EffectStack {
  constructor(items = []) { this.items = Array.isArray(items) ? items.slice() : []; }
  get size() { return this.items.length; }
  push(effect) { assert(effect && typeof effect.type === 'string', 'invalid-effect'); this.items.push(effect); return effect; }
  pushMany(effects) {
    const list = Array.isArray(effects) ? effects : [];
    for (let i = list.length - 1; i >= 0; i--) this.push(list[i]);
  }
  pop() { return this.items.pop() || null; }
  peek() { return this.items.length ? this.items[this.items.length - 1] : null; }
  clear() { this.items.length = 0; }
  toJSON() { return this.items.slice(); }
}

module.exports = { EffectStack };
