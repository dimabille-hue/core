'use strict';

/**
 * Builds the single execution context exposed to a trusted game pack.
 * Keeping context assembly outside game-engine.js makes the capability surface
 * reviewable in one place and prevents accidental coupling to domain modules.
 */
function createExecutionContext({
  api,
  state,
  players,
  random,
  knowledge,
  definition,
  meta,
  turnOrder,
  getCurrentActor,
  getCurrentAction,
  handlers,
  project,
}) {
  const ctx = {
    get engine() { return api; },
    get state() { return state; },
    get actor() { return getCurrentActor(); },
    get action() { return getCurrentAction(); },
    get players() { return players; },
    get random() { return random; },
    get knowledge() { return knowledge; },
    emit: handlers.emit,
    emitPresentation: handlers.emitPresentation,
    bump: handlers.bump,
    endTurn: handlers.endTurn,
    finish: handlers.finish,
    eliminate: handlers.eliminate,
    revive: handlers.revive,
    choose: handlers.choose,
    reaction: handlers.reaction,
    enqueue: handlers.enqueue,
    pushEffect: handlers.enqueue,
    schedule: handlers.schedule,
    cancelScheduled: handlers.cancelScheduled,
    pushEffects: handlers.pushEffects,
    cancelEffect: handlers.cancelEffect,
    requireTurn: id => {
      if (meta.active !== id) handlers.assert(false, 'not-your-turn');
    },
    setPhase: handlers.setPhase,
    setActive: handlers.setActive,
    public: handlers.public,
    scheduleAtTurn: handlers.scheduleAtTurn,
    now: () => ({ command: meta.commandSeq, turn: meta.turn }),
    get phase() { return meta.phase; },
    get turn() { return meta.turn; },
    get active() { return meta.active; },
    get turnOrder() { return turnOrder; },
    get pending() { return meta.pending; },
    project,
  };

  Object.defineProperty(ctx, 'services', {
    enumerable: true,
    get() { return definition.services || null; },
  });

  return ctx;
}

module.exports = { createExecutionContext };
