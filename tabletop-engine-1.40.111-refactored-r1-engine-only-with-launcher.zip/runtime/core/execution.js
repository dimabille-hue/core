'use strict';

/**
 * Engine callbacks are deliberately synchronous. A Promise crossing the command
 * boundary would mutate authoritative state after the command has committed,
 * breaking determinism, rollback and replay semantics.
 */
function assertSyncFunction(fn, label = 'callback') {
  if (typeof fn !== 'function') throw new TypeError(`${label}-function-required`);
  const constructorName = fn.constructor?.name;
  if (constructorName === 'AsyncFunction' || constructorName === 'AsyncGeneratorFunction') {
    const error = new Error(`async-callback-not-supported:${label}`);
    error.code = 'async-callback-not-supported';
    error.meta = { label }; 
    throw error;
  }
  return fn;
}

function assertSyncResult(result, label = 'callback') {
  if (result && typeof result.then === 'function') {
    const error = new Error(`async-callback-not-supported:${label}`);
    error.code = 'async-callback-not-supported';
    error.meta = { label };
    throw error;
  }
  return result;
}

function invokeSync(fn, context, args, label) {
  assertSyncFunction(fn, label);
  return assertSyncResult(fn(context, ...args), label);
}

module.exports = { assertSyncFunction, assertSyncResult, invokeSync };
