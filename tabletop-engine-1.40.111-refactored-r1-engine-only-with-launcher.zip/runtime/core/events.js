'use strict';

const PUBLIC = null;
const PUBLIC_CURSOR = '@public-viewer';

function cursorKey(viewer) {
  if (viewer == null) return PUBLIC_CURSOR;
  if (Array.isArray(viewer)) return `@set:${viewer.slice().sort().join('|')}`;
  return String(viewer);
}

function audienceContains(audience, viewer) {
  if (audience === PUBLIC) return true;
  if (Array.isArray(audience)) return audience.includes(viewer);
  return audience === viewer;
}

/**
 * Bounded event store with independent retention windows per stream.
 *
 * State and presentation events have different delivery semantics. They must
 * never evict each other, so each stream owns an independent ring buffer and
 * sequence. Event IDs remain globally monotonic for diagnostics and combined
 * history views; client cursors are stream-local sequences.
 */
class EventLog {
  constructor(capacity = 1024, options = {}) {
    const defaultCapacity = Math.max(32, Number(capacity) | 0);
    this.capacity = defaultCapacity;
    this.streamCapacities = new Map([
      ['state', defaultCapacity],
      ['presentation', Math.max(32, Number(options.presentationCapacity ?? defaultCapacity) | 0)]
    ]);
    this.nextId = 1;
    this.streamSeq = new Map();
    this.cursors = new Map();
    this._streams = new Map();
  }

  _capacity(streamName) {
    return this.streamCapacities.get(streamName) || this.capacity;
  }

  _stream(streamName) {
    let state = this._streams.get(streamName);
    if (!state) {
      const capacity = this._capacity(streamName);
      state = { capacity, ring: new Array(capacity), head: 0, count: 0 };
      this._streams.set(streamName, state);
    }
    return state;
  }

  _streamChronological(state) {
    const out = new Array(state.count);
    for (let i = 0; i < state.count; i++) {
      out[i] = state.ring[(state.head + i) % state.capacity];
    }
    return out;
  }

  _allChronological() {
    const out = [];
    for (const state of this._streams.values()) out.push(...this._streamChronological(state));
    out.sort((a, b) => a.id - b.id);
    return out;
  }

  _evictOldest(streamName) {
    const state = this._stream(streamName);
    if (!state.count) return;
    state.ring[state.head] = undefined;
    state.head = (state.head + 1) % state.capacity;
    state.count--;
  }

  append(type, payload = {}, audience = PUBLIC, revision = 0, stream = 'state') {
    const streamName = String(stream || 'state');
    const state = this._stream(streamName);
    const seq = (this.streamSeq.get(streamName) || 0) + 1;
    this.streamSeq.set(streamName, seq);
    const event = Object.freeze({
      id: this.nextId++,
      seq,
      revision,
      type,
      payload,
      audience,
      stream: streamName
    });

    if (state.count >= state.capacity) this._evictOldest(streamName);
    const pos = (state.head + state.count) % state.capacity;
    state.ring[pos] = event;
    state.count++;
    return event;
  }

  visible(viewer = PUBLIC, stream = null) {
    if (stream != null) {
      const state = this._streams.get(String(stream || 'state'));
      if (!state) return [];
      return this._streamChronological(state).filter(event => audienceContains(event.audience, viewer));
    }
    return this._allChronological().filter(event => audienceContains(event.audience, viewer));
  }

  consume(viewer = PUBLIC, stream = 'state') {
    const streamName = String(stream || 'state');
    const key = `${streamName}::${cursorKey(viewer)}`;
    const last = this.cursors.get(key) || 0;
    const state = this._streams.get(streamName);
    if (!state) return [];
    const out = [];
    let newest = last;
    for (const event of this._streamChronological(state)) {
      if (event.seq > last) {
        newest = Math.max(newest, event.seq);
        if (audienceContains(event.audience, viewer)) out.push(event);
      }
    }
    this.cursors.set(key, newest);
    return out;
  }

  since(cursor = 0, viewer = PUBLIC, stream = null) {
    const n = Number(cursor) || 0;
    if (stream != null) {
      const streamName = String(stream || 'state');
      const state = this._streams.get(streamName);
      if (!state) return [];
      return this._streamChronological(state).filter(event => event.seq > n && audienceContains(event.audience, viewer));
    }
    return this._allChronological().filter(event => event.id > n && audienceContains(event.audience, viewer));
  }

  cursor(viewer = PUBLIC, stream = 'state') {
    return this.cursors.get(`${String(stream || 'state')}::${cursorKey(viewer)}`) || 0;
  }

  window(stream = null) {
    if (stream == null) {
      const items = this._allChronological();
      return {
        oldest: items.length ? items[0].id : this.nextId,
        newest: items.length ? items[items.length - 1].id : this.nextId - 1
      };
    }

    const streamName = String(stream || 'state');
    const state = this._streams.get(streamName);
    const latest = this.streamSeq.get(streamName) || 0;
    if (!state || !state.count) return { oldest: latest + 1, newest: latest };
    const items = this._streamChronological(state);
    return { oldest: items[0].seq, newest: items[items.length - 1].seq };
  }

  // Compatibility getter. Only materializes the bounded combined history.
  get items() { return this._allChronological(); }
  get size() { let total = 0; for (const s of this._streams.values()) total += s.count; return total; }

  clear() {
    this.cursors.clear();
    this.streamSeq.clear();
    this._streams.clear();
    this.nextId = 1;
  }

  serialize() {
    return {
      capacity: this.capacity,
      streamCapacities: Object.fromEntries(this.streamCapacities),
      nextId: this.nextId,
      streamSeq: Object.fromEntries(this.streamSeq),
      items: this._allChronological().map(e => ({ ...e })),
      cursors: Object.fromEntries(this.cursors)
    };
  }

  restore(data) {
    this.clear();
    this.nextId = Number(data?.nextId) || 1;
    if (data?.streamCapacities && typeof data.streamCapacities === 'object') {
      for (const [name, cap] of Object.entries(data.streamCapacities)) {
        this.streamCapacities.set(String(name), Math.max(32, Number(cap) | 0));
      }
    }
    this.streamSeq = new Map(Object.entries(data?.streamSeq || {}).map(([k, v]) => [k, Number(v) || 0]));
    const items = Array.isArray(data?.items) ? data.items.slice() : [];
    items.sort((a, b) => Number(a?.id || 0) - Number(b?.id || 0));
    for (const raw of items) {
      const stream = String(raw.stream || 'state');
      const state = this._stream(stream);
      const seq = Number(raw.seq) || ((this.streamSeq.get(stream) || 0) + 1);
      this.streamSeq.set(stream, Math.max(this.streamSeq.get(stream) || 0, seq));
      const event = Object.freeze({ ...raw, stream, seq });
      if (state.count >= state.capacity) this._evictOldest(stream);
      const pos = (state.head + state.count) % state.capacity;
      state.ring[pos] = event;
      state.count++;
    }
    for (const event of this._allChronological()) this.nextId = Math.max(this.nextId, event.id + 1);
    this.cursors = new Map(Object.entries(data?.cursors || {}).map(([k, v]) => [k, Number(v) || 0]));
  }
}

module.exports = { PUBLIC, audienceContains, EventLog };
