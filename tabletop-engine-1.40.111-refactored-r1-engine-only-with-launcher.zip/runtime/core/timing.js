'use strict';

const { assert } = require('./errors');

const PHASES = Object.freeze(['before', 'resolve', 'after']);

function makeWindow(spec = {}, turnOrder = []) {
  const participants = [...new Set(spec.players || turnOrder)].filter(Boolean);
  assert(participants.length > 0, 'no-window-participants');
  return {
    id: spec.id,
    type: spec.type || 'REACTION',
    timing: spec.timing || 'before',
    participants,
    priority: Array.isArray(spec.priority) && spec.priority.length ? spec.priority.filter(p => participants.includes(p)) : participants.slice(),
    responses: Object.create(null),
    options: spec.options == null ? null : spec.options,
    data: spec.data == null ? null : spec.data,
    public: spec.public !== false,
    revealResponses: spec.revealResponses === true,
    closeBy: spec.closeBy ?? participants[0],
    allowMultiple: spec.allowMultiple === true,
    closeWhen: spec.closeWhen || 'manual'
  };
}

function orderedResponses(window) {
  return window.priority
    .filter(player => window.responses[player])
    .map(player => ({ player, ...window.responses[player] }));
}

function allAnswered(window) {
  return window.participants.every(player => !!window.responses[player]);
}

module.exports = { PHASES, makeWindow, orderedResponses, allAnswered };
