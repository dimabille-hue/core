'use strict';

const crypto = require('node:crypto');

function stable(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
  return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stable(value[k])).join(',') + '}';
}

function hash(value) {
  return crypto.createHash('sha256').update(stable(value)).digest('hex');
}

/**
 * Re-executes an exported replay against a supplied game definition. The
 * definition is intentionally an explicit argument: a replay is portable data,
 * not executable code and must never dynamically load arbitrary modules.
 */
function replay(record, definition, createEngine, options = {}) {
  if (!record || record.formatVersion !== 1) throw new Error('unsupported-replay-format');
  if (!definition || typeof createEngine !== 'function') throw new Error('replay-definition-required');
  if (record.truncated) throw new Error('replay-log-truncated');
  const engine = createEngine(definition, {
    ...options,
    seed: record.seed,
    replayLogCapacity: Math.max(Number(options.replayLogCapacity) || 0, record.commands?.length || 1)
  });
  for (const player of record.players || []) engine.addPlayer(player.id, player);
  engine.start(record.startOptions || {});
  for (const entry of record.commands || []) engine.dispatch(entry.actor, entry.command);
  const actualHash = engine.replayHash();
  return { engine, actualHash, expectedHash: record.finalHash || null, matches: !record.finalHash || actualHash === record.finalHash };
}

module.exports = { stable, hash, replay };
