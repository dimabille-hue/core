'use strict';

const { assert } = require('./errors');

class TurnOrder {
  constructor(ids = []) {
    this.ids = ids.slice();
    this.index = 0;
  }

  current() { return this.ids[this.index] ?? null; }

  set(ids, current = null) {
    this.ids = ids.slice();
    const i = current == null ? -1 : this.ids.indexOf(current);
    this.index = i >= 0 ? i : 0;
  }

  next(steps = 1) {
    if (!this.ids.length) return null;
    this.index = (this.index + Number(steps || 1)) % this.ids.length;
    if (this.index < 0) this.index += this.ids.length;
    return this.current();
  }

  previous(steps = 1) { return this.next(-Number(steps || 1)); }

  skip(count = 1) { return this.next(count); }

  remove(id) {
    const i = this.ids.indexOf(id);
    if (i < 0) return false;
    this.ids.splice(i, 1);
    if (!this.ids.length) this.index = 0;
    else if (i < this.index) this.index--;
    else if (this.index >= this.ids.length) this.index = 0;
    return true;
  }

  add(id) {
    assert(!this.ids.includes(id), 'player-already-in-turn-order');
    this.ids.push(id);
    return id;
  }

  serialize() { return { ids: this.ids.slice(), index: this.index }; }
  restore(data) { this.ids = Array.isArray(data?.ids) ? data.ids.slice() : []; this.index = Number(data?.index) | 0; }
}

module.exports = { TurnOrder };
