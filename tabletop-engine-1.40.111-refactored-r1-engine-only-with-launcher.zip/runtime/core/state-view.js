'use strict';

const { projectFields } = require('./visibility');
const { assertSyncFunction, assertSyncResult } = require('./execution');

function createStateView({ engineVersion, definitionId, definitionProject, state, meta, players, turnOrder, knowledge, clone, getAvailableActions }) {
  function publicPlayer(p) {
    return {
      id: p.id,
      name: p.name ?? null,
      ready: !!p.ready,
      connected: p.connected !== false,
      eliminated: !!p.eliminated,
    };
  }

  function publicPending(p) {
    const out = { id: p.id, kind: p.kind, type: p.type, public: p.public, data: p.data };
    if (p.kind === 'decision') {
      out.player = p.player;
      out.options = p.options;
      out.commands = p.commands.slice();
    } else {
      out.players = p.players.slice();
      out.priority = p.priority.slice();
      out.timing = p.timing;
      out.allowMultiple = p.allowMultiple;
      out.closeWhen = p.closeWhen;
      out.options = p.options;
      out.closeBy = p.closeBy;
      out.revealResponses = !!p.revealResponses;
      out.cancelOn = p.cancelOn;
      out.responses = p.revealResponses ? p.responses : Object.keys(p.responses).length;
    }
    return out;
  }

  function visiblePending(viewer) {
    if (!meta.pending) return null;
    if (meta.pending.public || meta.pending.player === viewer || meta.pending.players?.includes(viewer) || meta.pending.closeBy === viewer) {
      return publicPending(meta.pending);
    }
    return null;
  }

  function project(value, viewer, policies = {}) {
    return projectFields(value, policies, {
      viewer,
      knowledge: knowledge.get(viewer),
      state,
      players,
      phase: meta.phase,
      turn: meta.turn,
    });
  }

  function makeSnapshot(viewer) {
    const base = {
      engine: engineVersion,
      definition: definitionId,
      revision: meta.revision,
      phase: meta.phase,
      turn: meta.turn,
      active: meta.active,
      winner: meta.winner,
      pending: visiblePending(viewer),
      players: [...players.values()].map(publicPlayer),
      turnOrder: turnOrder.ids.slice(),
      availableActions: getAvailableActions(viewer),
    };
    assertSyncFunction(definitionProject, 'PROJECT');
    const knowledgeView = viewer == null ? knowledge.get(null) : knowledge.get(viewer);
    const projected = assertSyncResult(definitionProject(state, viewer, base, {
      viewer,
      knowledge: knowledgeView,
      state,
      players,
      phase: meta.phase,
      turn: meta.turn,
      active: meta.active,
    }), 'PROJECT');
    return clone(projected);
  }

  return { publicPlayer, publicPending, visiblePending, project, makeSnapshot };
}

module.exports = { createStateView };
