'use strict';

// Small deterministic PRNG with serializable state. Every random decision in
// the game should come from this source so a match can be reproduced.
class Random {
  constructor(seed = Date.now(), state = null) {
    this.seed = Number(seed) >>> 0;
    this._state = state == null ? (this.seed || 0x9e3779b9) : (Number(state) >>> 0);
  }

  next() {
    let s = this._state | 0;
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    this._state = s >>> 0;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  int(maxExclusive) {
    const max = Number(maxExclusive);
    if (!Number.isInteger(max) || max <= 0) throw new RangeError('max-exclusive-must-be-positive-integer');
    return Math.floor(this.next() * max);
  }

  range(minInclusive, maxInclusive) {
    const min = Number(minInclusive), max = Number(maxInclusive);
    if (!Number.isInteger(min) || !Number.isInteger(max) || max < min) throw new RangeError('invalid-range');
    return min + this.int(max - min + 1);
  }

  pick(items) {
    if (!Array.isArray(items) || items.length === 0) return null;
    return items[this.int(items.length)];
  }

  shuffle(items) {
    for (let i = items.length - 1; i > 0; i--) {
      const j = this.int(i + 1);
      [items[i], items[j]] = [items[j], items[i]];
    }
    return items;
  }

  get state() { return this._state >>> 0; }
  set state(value) { this._state = Number(value) >>> 0; }

  serialize() { return { seed: this.seed >>> 0, state: this.state }; }
}

function rng(seed) {
  const r = new Random(seed);
  const fn = () => r.next();
  fn.int = n => r.int(n);
  fn.pick = a => r.pick(a);
  fn.shuffle = a => r.shuffle(a);
  fn.serialize = () => r.serialize();
  fn.getState = () => r.state;
  fn.setState = s => { r.state = s; };
  return fn;
}

module.exports = { Random, rng };
