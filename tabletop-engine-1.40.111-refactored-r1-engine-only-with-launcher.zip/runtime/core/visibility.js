
'use strict';

function getPath(value, path) {
  if (value == null) return undefined;
  const parts = Array.isArray(path) ? path : String(path).split('.');
  let cur = value;
  for (const part of parts) {
    if (cur == null) return undefined;
    cur = cur[part];
  }
  return cur;
}

function resolvePolicy(policy, context, value, source) {
  return typeof policy === 'function' ? !!policy(context, value, source) : policy !== false;
}

// Generic, allocation-light field projection. The kernel knows only about
// viewers and policies; the meaning of a field belongs to the game/domain.
function projectFields(source, policies, context) {
  const out = {};
  if (!source || typeof source !== 'object') return out;
  for (const [field, policy] of Object.entries(policies || {})) {
    if (resolvePolicy(policy, context, source[field], source)) out[field] = source[field];
  }
  return out;
}

function reveal(value, visible) { return visible ? value : undefined; }

const policies = Object.freeze({
  public: () => true,
  hidden: () => false,
  owner: (ownerField = 'owner') => (ctx, _value, source) => ctx.viewer != null && source?.[ownerField] === ctx.viewer,
  known: (pathOrResolver) => (ctx, _value, source) => {
    const path = typeof pathOrResolver === 'function' ? pathOrResolver(ctx, source) : pathOrResolver;
    return getPath(ctx.knowledge, path) !== undefined;
  },
  publicAfter: predicate => (ctx, value, source) => !!predicate(ctx, value, source),
  when: (predicate, yes = policies.public, no = policies.hidden) => (ctx, value, source) => {
    const selected = predicate(ctx, value, source) ? yes : no;
    return resolvePolicy(selected, ctx, value, source);
  },
  anyOf: (...items) => (ctx, value, source) => items.some(item => resolvePolicy(item, ctx, value, source)),
  allOf: (...items) => (ctx, value, source) => items.every(item => resolvePolicy(item, ctx, value, source)),
});

module.exports = { projectFields, reveal, policies, getPath };
