'use strict';

/**
 * Synchronous FIFO dispatcher. Handlers may emit more events, but those events
 * are queued instead of recursively invoking the handler stack. This makes
 * event cascades bounded and observable without consuming the JS call stack.
 */
class EventDispatcher {
  constructor(limit = 4096) {
    this.limit = Math.max(32, Number(limit) | 0);
    this.queue = [];
    this.running = false;
  }

  enqueue(event, handler) {
    this.queue.push({ event, handler });
    if (this.running) return;
    this.running = true;
    let processed = 0;
    try {
      while (this.queue.length) {
        if (++processed > this.limit) {
          const error = new Error('event-loop-limit');
          error.code = 'event-loop-limit';
          throw error;
        }
        const item = this.queue.shift();
        item.handler(item.event);
      }
    } finally {
      this.running = false;
      this.queue.length = 0;
    }
  }
}

module.exports = { EventDispatcher };
