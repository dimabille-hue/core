# Tabletop Runtime — Engine-only Distribution 1.40.111-R1

This directory is the executable universal runtime. Game packs are external ZIP artifacts and are not embedded in this engine-only distribution.

## R1 runtime contract

- authoritative simulation is server-side in production;
- game callbacks are synchronous;
- state and presentation event streams have independent retention;
- event cascades are iterative and budgeted;
- card projection fails closed by default;
- production player identity is token-bound;
- Pack Manager mutations require admin authorization;
- pack installation is staged and rollback-safe;
- only allowlisted pack paths are web-public;
- `npm test` validates the distribution-level hardening invariants.

## External game packs

Put signed `game-pack-<gameId>.zip` files into the configured `game-packs/` directory. See:

- `../DISTRIBUTION_ARCHITECTURE_1.40.111.md`
- `../GAME_PACK_REFACTOR_GUIDE_1.40.111_R1.md`
- `PACK_SECURITY.md`

## Important security model

Pack signatures establish provenance and integrity. They do **not** sandbox JavaScript. In-process CommonJS game packs must be considered trusted code. Truly untrusted third-party packs require OS/container process isolation.

## Validation

From the root of the distribution:

```bash
npm test
```

Do not treat successful Node tests as a substitute for real Android/TV/browser smoke tests.

## Historical project context

The original development master contained a larger embedded game-pack tree and wider project scripts. The engine-only archive intentionally omits those developer/source artifacts.
