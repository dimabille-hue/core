'use strict';
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const PUBLIC_KEY_PATH=path.join(__dirname,'trust','pack-ed25519-public.pem');
function canonicalManifest(manifest){const copy={...manifest};delete copy.signature;return JSON.stringify(copy,Object.keys(copy).sort());}
function sha256(buf){return crypto.createHash('sha256').update(buf).digest('hex');}
function canonicalPayload(manifest,fileHashes){
  const hashes={};for(const k of Object.keys(fileHashes).sort())hashes[k]=fileHashes[k];
  return Buffer.from(canonicalManifest(manifest)+'\n'+JSON.stringify(hashes,Object.keys(hashes).sort()));
}
function signPack(manifest,fileBuffers,privateKeyPem){
  const hashes={};for(const [name,buf] of fileBuffers)if(name!=='manifest.json'&&!name.endsWith('/'))hashes[name]=sha256(buf);
  const payload=canonicalPayload(manifest,hashes);
  const signature=crypto.sign(null,payload,privateKeyPem).toString('base64');
  return {algorithm:'Ed25519',keyId:'tabletop-engine-official-v1',signature,files:hashes};
}
function verifyPack(manifest,fileBuffers,publicKeyPem=fs.readFileSync(PUBLIC_KEY_PATH,'utf8')){
  const sig=manifest&&manifest.signature;
  if(!sig||sig.algorithm!=='Ed25519'||sig.keyId!=='tabletop-engine-official-v1'||typeof sig.signature!=='string'||!sig.files||typeof sig.files!=='object') return {ok:false,reason:'missing-or-invalid-signature'};
  const actual={};for(const [name,buf] of fileBuffers)if(name!=='manifest.json'&&!name.endsWith('/'))actual[name]=sha256(buf);
  const expectedKeys=Object.keys(actual).sort(), signedKeys=Object.keys(sig.files).sort();
  if(expectedKeys.length!==signedKeys.length||expectedKeys.some((k,i)=>k!==signedKeys[i]||actual[k]!==sig.files[k])) return {ok:false,reason:'file-integrity-mismatch'};
  const payload=canonicalPayload(manifest,actual);
  let ok=false;try{ok=crypto.verify(null,payload,publicKeyPem,Buffer.from(sig.signature,'base64'));}catch{}
  return ok?{ok:true}:{ok:false,reason:'signature-verification-failed'};
}
module.exports={signPack,verifyPack,canonicalPayload,canonicalManifest,sha256,PUBLIC_KEY_PATH};
