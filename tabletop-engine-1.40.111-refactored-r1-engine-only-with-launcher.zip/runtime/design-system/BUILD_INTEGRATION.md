# Integration checklist

- [ ] Import only `index.css`, `player.css`, or `tv.css` as appropriate.
- [ ] Replace hard-coded UI colors with semantic tokens.
- [ ] Replace game action text buttons with icon buttons on mobile.
- [ ] Add `aria-label` to every icon-only action.
- [ ] Verify 44×44 minimum touch targets.
- [ ] Test safe-area on iOS/Android.
- [ ] Test 360×640, 390×844, 430×932, 768×1024, 1280×720, 1920×1080.
- [ ] Verify reduced-motion mode.
- [ ] Keep TV presentation events out of Player rendering.
- [ ] Keep game rules out of the design-system package.
