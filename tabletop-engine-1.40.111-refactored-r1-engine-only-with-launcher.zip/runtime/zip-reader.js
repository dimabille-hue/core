'use strict';
const fs = require('node:fs');
const zlib = require('node:zlib');

// Minimal ZIP reader for trusted/local game-pack distribution archives.
// Supports stored (method 0) and deflated (method 8) files and rejects unsafe paths.
function u16(b,o){return b.readUInt16LE(o);}
function u32(b,o){return b.readUInt32LE(o);}
function safeName(name){
  if(!name || name.startsWith('/') || /^[A-Za-z]:/.test(name)) return false;
  const parts=name.split('/');
  return !parts.some(p=>p==='' || p==='.' || p==='..');
}
function findEOCD(buf){
  const start=Math.max(0,buf.length-65557);
  for(let i=buf.length-22;i>=start;i--){if(buf.readUInt32LE(i)===0x06054b50)return i;}
  throw new Error('invalid-zip:no-eocd');
}
function readEntries(file){
  const maxArchive=Number(process.env.TABLETOP_ZIP_MAX_ARCHIVE||60*1024*1024);
  const stat=fs.statSync(file);
  if(stat.size>maxArchive) throw new Error('invalid-zip:archive-too-large');
  const buf=fs.readFileSync(file);
  const maxEntries=Number(process.env.TABLETOP_ZIP_MAX_ENTRIES||10000);
  const maxTotal=Number(process.env.TABLETOP_ZIP_MAX_UNCOMPRESSED||50*1024*1024);
  const maxFile=Number(process.env.TABLETOP_ZIP_MAX_FILE||10*1024*1024);
  const e=findEOCD(buf);
  const count=u16(buf,e+10), cdSize=u32(buf,e+12), cdOffset=u32(buf,e+16);
  if(count>maxEntries) throw new Error('invalid-zip:too-many-entries');
  if(cdOffset+cdSize>buf.length) throw new Error('invalid-zip:central-directory');
  const out=new Map();
  let totalUncomp=0;
  let p=cdOffset;
  for(let i=0;i<count;i++){
    if(p+46>cdOffset+cdSize || p+46>buf.length) throw new Error('invalid-zip:central-entry-bounds');
    if(buf.readUInt32LE(p)!==0x02014b50) throw new Error('invalid-zip:central-entry');
    const method=u16(buf,p+10), comp=u32(buf,p+20), uncomp=u32(buf,p+24);
    const nameLen=u16(buf,p+28), extraLen=u16(buf,p+30), commentLen=u16(buf,p+32), local=u32(buf,p+42);
    if(p+46+nameLen+extraLen+commentLen>cdOffset+cdSize || p+46+nameLen+extraLen+commentLen>buf.length) throw new Error('invalid-zip:central-entry-bounds');
    const name=buf.subarray(p+46,p+46+nameLen).toString('utf8');
    if(!safeName(name.endsWith('/') ? name.slice(0,-1) : name)) throw new Error(`invalid-zip:unsafe-path:${name}`);
    if(out.has(name)) throw new Error(`invalid-zip:duplicate-entry:${name}`);
    if(uncomp>maxFile) throw new Error(`invalid-zip:file-too-large:${name}`);
    totalUncomp+=uncomp; if(totalUncomp>maxTotal) throw new Error('invalid-zip:total-uncompressed-too-large');
    if(comp>buf.length) throw new Error(`invalid-zip:compressed-size:${name}`);
    out.set(name,{file,buf,method,comp,uncomp,local,name});
    p+=46+nameLen+extraLen+commentLen;
  }
  return out;
}
function readEntry(entry){
  const b=entry.buf, p=entry.local;
  if(b.readUInt32LE(p)!==0x04034b50) throw new Error(`invalid-zip:local-header:${entry.name}`);
  const nameLen=u16(b,p+26), extraLen=u16(b,p+28);
  const dataStart=p+30+nameLen+extraLen;
  if(dataStart<0 || dataStart+entry.comp>b.length) throw new Error(`invalid-zip:data-bounds:${entry.name}`);
  const compressed=b.subarray(dataStart,dataStart+entry.comp);
  let data;
  if(entry.method===0) data=Buffer.from(compressed);
  else if(entry.method===8) data=zlib.inflateRawSync(compressed);
  else throw new Error(`unsupported-zip-method:${entry.method}:${entry.name}`);
  if(data.length!==entry.uncomp) throw new Error(`invalid-zip:size:${entry.name}`);
  return data;
}
function extractZip(file,dest){
  const entries=readEntries(file);
  fs.mkdirSync(dest,{recursive:true});
  for(const [name,entry] of entries){
    if(name.endsWith('/')) continue;
    const target=pathResolveSafe(dest,name);
    fs.mkdirSync(require('node:path').dirname(target),{recursive:true});
    fs.writeFileSync(target,readEntry(entry));
  }
  return [...entries.keys()];
}
function pathResolveSafe(root,rel){
  const path=require('node:path');
  const out=path.resolve(root,rel);
  if(out!==path.resolve(root) && !out.startsWith(path.resolve(root)+path.sep)) throw new Error(`unsafe-path:${rel}`);
  return out;
}
module.exports={readEntries,readEntry,extractZip};
