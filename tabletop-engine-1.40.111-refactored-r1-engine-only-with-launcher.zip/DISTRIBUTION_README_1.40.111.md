# Tabletop Engine Distribution — 1.40.111

1. Extract the engine ZIP.
2. Put independent game-pack ZIPs into `game-packs/`.
3. Start the engine with `npm start`.
4. Open the Launcher. Installed packs appear as game cards automatically.
5. Use Pack Manager to install a ZIP, rescan, or remove a pack.

A game pack is independent of the engine build. Updating a game means replacing its pack ZIP; updating the engine does not require rebuilding installed games.

## Security
Production engine distributions accept only Ed25519-signed game-pack ZIPs. Unsigned packs are intended only for controlled development. Signing protects provenance/integrity; it is not a JavaScript sandbox.
