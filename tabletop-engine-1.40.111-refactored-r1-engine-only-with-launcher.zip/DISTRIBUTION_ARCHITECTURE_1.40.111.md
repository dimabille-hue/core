# Distribution Architecture — 1.40.111

## Engine / Game Pack separation

The engine and games are separate distribution artifacts.

- `tabletop-engine-1.40.111.zip` contains the engine runtime, launcher and Pack Manager.
- Each `game-pack-<gameId>.zip` contains exactly one independent game.
- `tabletop-game-packs-1.40.111.zip` is only a convenience collection of independent pack ZIPs.
- Production engine runtime contains no embedded game implementations.

## Drop-in contract

Place one or more game-pack ZIP files in the engine's external `game-packs/` directory. On the next catalog refresh the engine:

1. scans ZIPs and directories;
2. validates the manifest and pack format;
3. checks engine compatibility;
4. extracts ZIP contents into an internal cache;
5. exposes Player, TV, Preview and server definition according to declared capabilities;
6. reports invalid/incompatible packages without hiding valid packages.

No engine rebuild is required when adding or replacing a game pack.

## Security

External ZIP packs are treated as executable server code, so production mode requires an Ed25519 signature before extraction and execution. The signature covers the canonical manifest plus SHA-256 hashes of every pack file. ZIP path traversal, duplicate entries, oversized files and oversized total decompression are rejected. Signature validation establishes provenance and integrity; it does **not** sandbox JavaScript. Truly untrusted third-party packs must run in a separate OS/container process with reduced privileges.

For controlled development only, `TABLETOP_ALLOW_UNSIGNED_PACKS=1` or `security:'permissive'` may be used.

## Pack Manager

`/pack-manager` provides install/upload, rescan, and remove operations. Uploading a pack with the same `gameId` replaces the installed archive after validation. The manager never trusts an archive until its manifest, entrypoint and declared surfaces pass validation.

## Launcher

The launcher renders one responsive card per installed game. The dominant element is a game cover. Actions use large icon-first buttons for Play, Preview and Pack Manager. The launcher is entirely catalog-driven; it contains no game-specific ID branches.

## Public coupling rule

Game packs may depend on the stable engine Pack API. They must not import engine source through repository-relative paths. Engine implementation details remain private to the engine distribution.

## R1 hardening addendum

### Production admission

Production MatchHost requires identity binding by default. Join tokens are HMAC-SHA256 signed and scoped to:

- match ID;
- principal;
- role;
- expiry.

Set `TABLETOP_JOIN_SECRET` and keep anonymous mode disabled.

### Match resources

Each MatchHost has a configurable match cap (`TABLETOP_MAX_MATCHES_PER_GAME`) and optional idle cleanup (`TABLETOP_MATCH_IDLE_TTL_MS`). Arbitrary dynamic match creation is disabled by default in production unless `TABLETOP_AUTO_CREATE_MATCHES=1` is explicitly set.

### Pack Manager authorization

`POST /api/packs/install`, `POST /api/packs/scan` and `DELETE /api/packs/<id>` require `X-Tabletop-Admin-Token` when `TABLETOP_ADMIN_TOKEN` is configured. A trusted-localhost bypass is available only when `TABLETOP_PACK_MANAGER_ALLOW_LOCALHOST=1` is explicitly enabled.

### Staged install

An incoming pack is fully validated before replacing the current archive. The previous archive is kept as a rollback backup until the new pack has been refreshed and loaded successfully.

### Public files

Pack files are not automatically web-public. Default public roots are:

```text
preview/
player-ui/
tv-ui/
assets/
public/
```

A pack may declare an explicit `publicPaths` allowlist in `manifest.json`. Server-side code must never be placed on the public path.

### Distribution tests

The engine-only archive contains a self-contained `npm test` suite in `test/refactor-hardening.cjs`. The original developer repository test tree is intentionally not required for the production distribution validation.

### Architecture baseline

The R1 baseline is documented in `TECHNICAL_AUDIT_1.40.111_R1.md`. It is a hardening/refactor baseline, not the final architecture. Known next-phase work includes controlled state mutation, side-effect transactions, sandbox/process isolation for untrusted packs, viewer-specific canonical event projection and checkpointed replay.
