'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const cp = require('node:child_process');
const { createEngine, replay, EventLog } = require('../runtime');
const { PackManager } = require('../runtime/pack-manager');
const { GamePackHost } = require('../runtime/pack-host');
const { issueJoinToken, verifyJoinToken } = require('../runtime/server/auth');
const { MatchHost } = require('../runtime/server/match-host');
const { SessionClient } = require('../runtime/client/session-client');
const { TYPE, frame, encode } = require('../runtime/server/protocol');
const { composeCardDefinition } = require('../runtime/domains/cards/card-dsl');

function test(name, fn) {
  try {
    fn();
    console.log(`ok - ${name}`);
  } catch (error) {
    console.error(`not ok - ${name}`);
    throw error;
  }
}

// Event streams own independent retention windows.
test('state and presentation streams do not evict each other', () => {
  const log = new EventLog(32, { presentationCapacity: 32 });
  for (let i = 0; i < 40; i++) log.append('STATE', { i }, null, i, 'state');
  for (let i = 0; i < 200; i++) log.append('FX', { i }, null, i, 'presentation');
  assert.equal(log.window('state').oldest, 9);
  assert.equal(log.window('state').newest, 40);
  assert.equal(log.window('presentation').oldest, 169);
  assert.equal(log.window('presentation').newest, 200);
});

// Event cascades are FIFO instead of recursive.
test('event cascades do not consume the JS call stack', () => {
  let count = 0;
  const engine = createEngine({
    id: 'event-queue',
    createState: () => ({ count: 0 }),
    project: (_state, _viewer, snapshot) => snapshot,
    onEvent: (ctx, event) => {
      if (event.type !== 'CHAIN') return;
      count++;
      if (count < 100) ctx.emit('CHAIN', {});
    },
    actions: {
      GO: ctx => { ctx.emit('CHAIN', {}); }
    }
  }, { seed: 7, eventCascadeLimit: 500 });
  engine.addPlayer('p1');
  engine.start();
  engine.dispatch('p1', { type: 'GO' });
  assert.equal(count, 100);
});

// Async callbacks are rejected before they can escape the command boundary.
test('async rule callbacks are rejected', () => {
  const engine = createEngine({
    id: 'async-rejection',
    createState: () => ({ value: 0 }),
    project: (_state, _viewer, snapshot) => snapshot,
    actions: {
      GO: async ctx => {
        await Promise.resolve();
        ctx.state.value = 100;
      }
    }
  }, { seed: 1 });
  engine.addPlayer('p1');
  engine.start();
  const result = engine.tryDispatch('p1', { type: 'GO' });
  assert.equal(result.ok, false);
  assert.equal(result.error.code, 'async-callback-not-supported');
  assert.equal(engine.state.value, 0);
});


// Initialization and projection callbacks are synchronous contracts too.
test('initialization and projection callbacks cannot escape the sync boundary', () => {
  assert.throws(() => createEngine({
    id: 'async-create',
    createState: async () => ({ bad: true }),
    project: (_state, _viewer, snapshot) => snapshot,
    actions: {}
  }), /async-callback-not-supported:CREATE_STATE/);

  const engine = createEngine({
    id: 'projection-contract',
    createState: () => ({ value: 7 }),
    project: (_state, _viewer, snapshot, extra) => ({ ...snapshot, publicValue: extra.state.value }),
    actions: {}
  });
  engine.addPlayer('p1');
  engine.start();
  assert.equal(engine.snapshot('p1').publicValue, 7);

  assert.throws(() => createEngine({
    id: 'async-project',
    createState: () => ({}),
    project: async () => ({ ok: true }),
    actions: {}
  }).snapshot(null), /async-callback-not-supported:PROJECT/);
});

// Replay is now a reproducible command stream rather than just a hash helper.
test('exported replay reproduces the authoritative state', () => {
  const definition = {
    id: 'replay-game',
    createState: () => ({ value: 0 }),
    project: (_state, _viewer, snapshot, extra) => ({ ...snapshot, publicValue: extra.state.value }),
    actions: {
      ADD: (ctx, command) => { ctx.state.value += Number(command.amount || 0); }
    }
  };
  const engine = createEngine(definition, { seed: 42 });
  engine.addPlayer('p1');
  engine.start();
  engine.dispatch('p1', { type: 'ADD', amount: 3 });
  engine.dispatch('p1', { type: 'ADD', amount: 9 });
  const record = engine.exportReplay();
  const result = replay(record, definition, createEngine);
  assert.equal(result.matches, true);
});


// Replay refuses to masquerade a truncated command log as a complete history.
test('truncated replay logs are rejected', () => {
  const engine = createEngine({
    id: 'truncated-replay',
    createState: () => ({ value: 0 }),
    project: (_state, _viewer, snapshot) => snapshot,
    actions: { INC: ctx => { ctx.state.value += 1; } }
  }, { seed: 9, commandLogCapacity: 1 });
  engine.addPlayer('p1');
  engine.start();
  engine.dispatch('p1', { type: 'INC' });
  engine.dispatch('p1', { type: 'INC' });
  assert.throws(() => engine.exportReplay(), /replay-log-truncated/);
});

// Card composition is fail-closed unless a public state projection is declared.
test('card DSL does not expose canonical state by default', () => {
  const definition = composeCardDefinition({ id: 'cards' }, []);
  const snapshot = { revision: 0 };
  const out = definition.project({ secret: 'keep-out', public: 7 }, 'p1', snapshot);
  assert.deepEqual(out, snapshot);

  const safe = composeCardDefinition({ id: 'cards' }, [], { publicStatePaths: ['public'] });
  const safeOut = safe.project({ secret: 'keep-out', public: 7 }, 'p1', snapshot);
  assert.equal(safeOut.state.public, 7);
  assert.equal('secret' in safeOut.state, false);
});

// Pack installation is staged and public file access is fail-closed.
test('pack manager keeps the current pack when replacement validation fails', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tabletop-refactor-pack-'));
  const source = path.join(root, 'source');
  const packDir = path.join(root, 'packs');
  fs.mkdirSync(path.join(source, 'preview'), { recursive: true });
  fs.mkdirSync(path.join(source, 'assets'), { recursive: true });
  fs.mkdirSync(path.join(source, 'player-ui'), { recursive: true });
  fs.writeFileSync(path.join(source, 'server.js'), "module.exports={id:'demo'};\n");
  fs.writeFileSync(path.join(source, 'preview', 'index.html'), '<html></html>');
  fs.writeFileSync(path.join(source, 'assets', 'cover.svg'), '<svg/>');
  fs.writeFileSync(path.join(source, 'player-ui', 'index.html'), '<html></html>');
  fs.writeFileSync(path.join(source, 'manifest.json'), JSON.stringify({
    schemaVersion: 1, packFormatVersion: 1, gameId: 'demo', name: 'Demo', version: '1.0.0',
    entry: 'server.js', engineCompatibility: '1.40.x', capabilities: ['player']
  }));
  const zip = path.join(root, 'demo.zip');
  cp.execFileSync('zip', ['-qr', zip, '.'], { cwd: source });

  const host = new GamePackHost({ engineVersion: '1.40.111', packDir, security: 'permissive' });
  const manager = new PackManager({ engineVersion: '1.40.111', packDir, host, security: 'permissive' });
  const installed = manager.install(zip, 'demo.zip');
  assert.equal(installed.manifest.gameId, 'demo');
  assert.throws(() => host.resolveFile('demo', 'server.js'), /pack-file-not-public/);
  assert.doesNotThrow(() => host.resolveFile('demo', 'assets/cover.svg'));

  fs.writeFileSync(path.join(source, 'manifest.json'), JSON.stringify({ schemaVersion: 1, packFormatVersion: 1, gameId: 'demo', name: 'Broken', version: '2.0.0', entry: 'server.js', engineCompatibility: '1.40.x', capabilities: ['player'] }));
  fs.rmSync(path.join(source, 'preview'), { recursive: true, force: true });
  const badZip = path.join(root, 'broken.zip');
  cp.execFileSync('zip', ['-qr', badZip, '.'], { cwd: source });
  assert.throws(() => manager.install(badZip, 'demo.zip'), /missing-preview/);
  assert.equal(manager.status().games[0].version, '1.0.0');

  fs.rmSync(root, { recursive: true, force: true });
});


// Production identity mode rejects arbitrary player IDs and accepts only scoped join tokens.
test('match host binds identity when authentication is required', () => {
  const host = new MatchHost({ requireIdentity: true, joinSecret: 'secret', maxMatches: 2 });
  host.createMatch('m1', { id: 'auth-game', createState: () => ({}), project: (_s, _v, snapshot) => snapshot });
  const sent = [];
  const session = { id: 's1', alive: true, send: msg => { sent.push(msg); return 1; }, close() {}, onClose: null };
  const controller = host.attach('m1', session);
  controller.receive(encode(frame(TYPE.JOIN, { role: 'player', id: 'attacker' })));
  assert.equal(sent.at(-1).code, 'invalid-identity-token');

  const token = issueJoinToken('secret', { match: 'm1', principal: 'p1', role: 'player' });
  controller.receive(encode(frame(TYPE.JOIN, { role: 'player', id: 'p1', authToken: token })));
  assert.equal(host.getMatch('m1').engine.players.has('p1'), true);
});


// Client API exposes the production join credential without changing resume semantics.
test('session clients forward authToken on JOIN', () => {
  const sent = [];
  const client = new SessionClient({ connect: async () => null, match: 'm1', principal: 'p1', authToken: 'token-1' });
  client.socket = { send: value => sent.push(JSON.parse(value)) };
  client.sendJoin();
  assert.equal(sent[0].authToken, 'token-1');
  assert.equal(sent[0].id, 'p1');
});

// Native HMAC join tokens bind identity to a concrete match and role.
test('join tokens are scoped and time-bound', () => {
  const token = issueJoinToken('secret', { match: 'm1', principal: 'p1', role: 'player', now: 1000, ttlMs: 5000 });
  assert.equal(verifyJoinToken('secret', token, { match: 'm1', principal: 'p1', role: 'player', now: 3000 }), true);
  assert.equal(verifyJoinToken('secret', token, { match: 'm2', principal: 'p1', role: 'player', now: 3000 }), false);
  assert.equal(verifyJoinToken('secret', token, { match: 'm1', principal: 'p1', role: 'viewer', now: 3000 }), false);
  assert.equal(verifyJoinToken('secret', token, { match: 'm1', principal: 'p1', role: 'player', now: 7000 }), false);
});


// Public launcher routes must not expose the Pack Manager scan mutation/read-through alias.
test('launcher does not expose public GET pack scan route', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'launcher', 'server.js'), 'utf8');
  assert.equal(source.includes("if(u==='/api/packs/scan')"), false);
});

console.log('refactor-hardening: PASS');
