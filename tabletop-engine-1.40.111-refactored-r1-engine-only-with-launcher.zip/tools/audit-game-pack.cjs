#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { readEntries, readEntry } = require('../runtime/zip-reader');
const { validateManifest, compatible } = require('../runtime/pack-host');
const ENGINE_VERSION = require('../package.json').version;

function fail(message) {
  console.error(`ERROR ${message}`);
  process.exitCode = 2;
}

function walk(dir, base = '') {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const rel = base ? `${base}/${entry.name}` : entry.name;
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(abs, rel));
    else if (entry.isFile()) out.push({ path: rel.replace(/\\/g, '/'), read: () => fs.readFileSync(abs) });
  }
  return out;
}

function loadPack(target) {
  const abs = path.resolve(target);
  if (fs.statSync(abs).isDirectory()) {
    const manifestPath = path.join(abs, 'manifest.json');
    if (!fs.existsSync(manifestPath)) throw new Error('missing-manifest');
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    return { manifest, files: walk(abs) };
  }
  const entries = readEntries(abs);
  const manifestEntry = entries.get('manifest.json');
  if (!manifestEntry) throw new Error('missing-manifest');
  const manifest = JSON.parse(readEntry(manifestEntry).toString('utf8'));
  const files = [...entries].map(([filePath, entry]) => ({ path: filePath, read: () => readEntry(entry) }));
  return { manifest, files };
}

function has(files, name) {
  return files.some(f => f.path === name);
}

function textFiles(files, predicate) {
  return files.filter(f => predicate(f.path)).map(f => ({ path: f.path, text: f.read().toString('utf8') }));
}

function main() {
  const target = process.argv[2];
  if (!target) {
    console.error('Usage: npm run audit:pack -- <pack-dir-or-zip>');
    process.exitCode = 2;
    return;
  }

  let pack;
  try { pack = loadPack(target); }
  catch (error) { fail(error.message || String(error)); return; }

  const { manifest, files } = pack;
  const findings = [];
  const warnings = [];
  try {
    validateManifest(manifest, { distribution: true });
  } catch (error) {
    findings.push(`manifest:${error.message}`);
  }
  if (!compatible(manifest.engineCompatibility, ENGINE_VERSION)) findings.push(`engine-incompatible:${manifest.engineCompatibility}`);
  if (!has(files, manifest.entry)) findings.push(`missing-entry:${manifest.entry}`);
  if (!has(files, 'preview/index.html')) findings.push('missing-preview');
  if (manifest.capabilities?.includes('player') && !has(files, 'player-ui/index.html')) findings.push('missing-player-surface');
  if (manifest.capabilities?.includes('tv') && !has(files, 'tv-ui/index.html')) findings.push('missing-tv-surface');

  if (manifest.capabilities?.includes('player') && !manifest.publicPaths) warnings.push('player-capability-without-explicit-publicPaths');
  if (manifest.capabilities?.includes('tv') && !manifest.publicPaths) warnings.push('tv-capability-without-explicit-publicPaths');
  if (!has(files, 'manifest.json')) findings.push('missing-manifest');

  const serverAndDomain = textFiles(files, p => p.endsWith('.js') && !p.startsWith('player-ui/') && !p.startsWith('tv-ui/') && !p.startsWith('preview/'));
  const serverText = serverAndDomain.map(f => `${f.path}\n${f.text}`).join('\n');
  const smells = [
    [/\basync\s*(function)?\b|\basync\s+[A-Za-z_$][\w$]*\s*=>/g, 'async-rule-code'],
    [/\bPromise\b/g, 'promise-in-rule-code'],
    [/Math\.random\s*\(/g, 'math-random-in-rule-code'],
    [/Date\.now\s*\(/g, 'wall-clock-in-rule-code'],
    [/new\s+Date\s*\(/g, 'wall-clock-date-in-rule-code'],
    [/require\s*\(\s*['"](?:node:)?(?:fs|fs\/promises|child_process|net|http|https|dgram|tls)['"]\s*\)/g, 'direct-node-io-in-rule-code'],
    [/process\.(?:env|exit|cwd|chdir|kill)/g, 'process-global-access-in-rule-code'],
  ];
  for (const [pattern, code] of smells) if (pattern.test(serverText)) findings.push(code);

  if (manifest.capabilities?.includes('player') || manifest.capabilities?.includes('tv')) {
    if (!serverText.includes('project')) warnings.push('no-explicit-project-function-detected');
  }
  if (manifest.legacyPublicState === true) findings.push('legacy-public-state-enabled');

  const nonPublicServerFiles = files.filter(f => !/^(preview|player-ui|tv-ui|assets|public)\//.test(f.path) && f.path !== 'manifest.json');
  const publicPaths = Array.isArray(manifest.publicPaths) ? manifest.publicPaths : ['preview/','player-ui/','tv-ui/','assets/','public/'];
  const publiclyReachableSensitive = files.filter(f => {
    const p = f.path;
    if (!/^(server|domain|rules|simulation|internal|private)\//.test(p) && p !== manifest.entry) return false;
    return publicPaths.some(prefix => p === prefix || p.startsWith(prefix.replace(/\/$/, '') + '/'));
  });
  if (publiclyReachableSensitive.length) findings.push(`sensitive-path-under-public-root:${publiclyReachableSensitive.map(x => x.path).join(',')}`);

  const summary = {
    verdict: findings.length ? 'BLOCKED' : warnings.length ? 'PASS WITH WARNINGS' : 'PASS',
    gameId: manifest.gameId || null,
    version: manifest.version || null,
    engineCompatibility: manifest.engineCompatibility || null,
    files: files.length,
    findings,
    warnings,
  };
  console.log(JSON.stringify(summary, null, 2));
  if (summary.verdict === 'BLOCKED') process.exitCode = 1;
}

main();
