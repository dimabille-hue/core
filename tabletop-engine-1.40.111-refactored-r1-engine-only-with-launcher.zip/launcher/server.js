'use strict';
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const { requireAdminToken } = require('../runtime/server/auth');
const {GamePackHost}=require('../runtime/pack-host');
const {PackManager}=require('../runtime/pack-manager');
const launcherRoot=path.resolve(__dirname,'public');
const runtimeRoot=path.resolve(__dirname,'..','runtime');
const engineVersion=JSON.parse(fs.readFileSync(path.resolve(__dirname,'..','package.json'),'utf8')).version;
const packHost=new GamePackHost({engineVersion,packDir:process.env.TABLETOP_GAME_PACKS_DIR});
const packManager=new PackManager({engineVersion,packDir:packHost.packDir,host:packHost});
const PACK_UPLOAD_MAX_BYTES=Math.max(1024*1024,Number(process.env.TABLETOP_PACK_UPLOAD_MAX||20*1024*1024));
const ADMIN_TOKEN=process.env.TABLETOP_ADMIN_TOKEN||'';
const ALLOW_LOCAL_ADMIN=process.env.TABLETOP_PACK_MANAGER_ALLOW_LOCALHOST==='1';
function isLocal(req){const r=req.socket?.remoteAddress||'';return r==='127.0.0.1'||r==='::1'||r==='::ffff:127.0.0.1';}
function requireAdmin(req,res){
 if(ADMIN_TOKEN && req.headers['x-tabletop-admin-token'] && requireAdminToken(req,ADMIN_TOKEN,{allowLoopback:false})) return true;
 if(ALLOW_LOCAL_ADMIN && isLocal(req)) return true;
 res.writeHead(403,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify({error:'admin-auth-required'}));return false;
}
const MIME=Object.freeze({'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp'});
function safe(root,rel){const file=path.resolve(root,rel.replace(/^\/+/,''));return file===path.resolve(root)||file.startsWith(path.resolve(root)+path.sep)?file:null;}
function catalog(){const games=packHost.list();return {runtimeVersion:engineVersion,games,errors:packHost.errorsSnapshot()};}
function coverSvg(game){
 const esc=(v)=>String(v||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
 const title=esc(game.name||game.gameId), id=esc(game.gameId);
 const hue=[...String(game.gameId||'game')].reduce((a,c)=>a+c.charCodeAt(0),0)%360;
 return `<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1200 675\"><defs><linearGradient id=\"g\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"hsl(${hue} 72% 34%)\"/><stop offset=\"1\" stop-color=\"hsl(${(hue+55)%360} 72% 12%)\"/></linearGradient></defs><rect width=\"1200\" height=\"675\" fill=\"url(#g)\"/><circle cx=\"980\" cy=\"130\" r=\"180\" fill=\"white\" opacity=\".08\"/><circle cx=\"1020\" cy=\"520\" r=\"260\" fill=\"white\" opacity=\".04\"/><text x=\"72\" y=\"500\" fill=\"white\" font-family=\"system-ui,sans-serif\" font-size=\"68\" font-weight=\"800\">${title}</text><text x=\"76\" y=\"558\" fill=\"white\" opacity=\".62\" font-family=\"monospace\" font-size=\"22\">${id}</text></svg>`;
}
function resolvePath(urlPath){
 const u=decodeURIComponent(urlPath.split('?')[0]||'/');
 if(u==='/'||u==='/index.html')return{file:path.join(launcherRoot,'index.html')};
 if(u==='/pack-manager'||u==='/pack-manager/')return{file:path.join(launcherRoot,'pack-manager.html')};
 if(u==='/catalog.json')return{json:catalog()};
 if(u==='/api/packs')return{json:packManager.status()};
 const cover=u.match(/^\/api\/packs\/([^/]+)\/cover\.svg$/); if(cover){try{const file=packManager.host.resolveFile(cover[1],'assets/cover.svg');return{file};}catch{try{const g=packManager.host.get(cover[1]);return{raw:Buffer.from(coverSvg(g),'utf8'),type:'image/svg+xml; charset=utf-8'};}catch{return null;}}}
 if(u==='/pack-errors.json')return{json:{errors:packHost.errorsSnapshot()}};
 if(u.startsWith('/client/'))return{file:safe(runtimeRoot,u.slice(1))};
 if(u.startsWith('/presentation/'))return{file:safe(runtimeRoot,u.slice(1))};
 if(u.startsWith('/design-system/'))return{file:safe(runtimeRoot,u.slice(1))};
 if(u.startsWith('/games/')){const m=u.match(/^\/games\/([^/]+)\/(.*)$/);if(!m)return null;try{return{file:packHost.resolveFile(m[1],m[2])};}catch(_){return null;}}
 return null;
}
async function readBody(req,maxBytes=PACK_UPLOAD_MAX_BYTES){const chunks=[];let total=0;for await(const c of req){total+=c.length;if(total>maxBytes){const e=new Error('request-body-too-large');e.code='request-body-too-large';throw e;}chunks.push(c);}return Buffer.concat(chunks);}
async function serve(req,res){
 const url=decodeURIComponent((req.url||'/').split('?')[0]);
 if(req.method==='POST' && url==='/api/packs/scan'){if(!requireAdmin(req,res))return;packManager.rescan();const data=Buffer.from(JSON.stringify(packManager.status()));res.writeHead(200,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});return res.end(data);}
 if(req.method==='DELETE' && url.startsWith('/api/packs/')){if(!requireAdmin(req,res))return;const id=url.split('/').filter(Boolean).pop();try{const out=packManager.uninstall(id);const data=Buffer.from(JSON.stringify(out));res.writeHead(200,{'content-type':'application/json; charset=utf-8'});return res.end(data);}catch(e){res.writeHead(400,{'content-type':'application/json; charset=utf-8'});return res.end(JSON.stringify({error:e.message}));}}
 if(req.method==='POST' && url==='/api/packs/install'){
  if(!requireAdmin(req,res))return;
  const len=Number(req.headers['content-length']||0);if(len>PACK_UPLOAD_MAX_BYTES){res.writeHead(413,{'content-type':'application/json; charset=utf-8'});return res.end(JSON.stringify({error:'request-body-too-large'}));}
  let body;try{body=await readBody(req);}catch(e){res.writeHead(413,{'content-type':'application/json; charset=utf-8'});return res.end(JSON.stringify({error:e.code||e.message}));}
  const ct=req.headers['content-type']||''; const m=ct.match(/^multipart\/form-data; boundary=(.+)$/i);
  if(!m){res.writeHead(415);return res.end('Expected multipart/form-data');}
  const boundary=Buffer.from(`--${m[1]}`); let start=0, fileBuf=null, filename='game-pack.zip';
  while((start=body.indexOf(boundary,start))!==-1){const hEnd=body.indexOf(Buffer.from('\r\n\r\n'),start);if(hEnd<0)break;const headers=body.slice(start+boundary.length,hEnd).toString('utf8');const next=body.indexOf(boundary,hEnd+4);if(next<0)break;const match=headers.match(/filename="([^"]+)"/i); if(match){filename=match[1];fileBuf=body.slice(hEnd+4,next-2);} start=next;}
  if(!fileBuf){res.writeHead(400);return res.end('Missing file');}
  const temp=path.join(os.tmpdir(),`tabletop-pack-${process.pid}-${Date.now()}.zip`);fs.writeFileSync(temp,fileBuf);
  try{const out=packManager.install(temp,filename);const data=Buffer.from(JSON.stringify(out));res.writeHead(200,{'content-type':'application/json; charset=utf-8'});return res.end(data);}catch(e){res.writeHead(400,{'content-type':'application/json; charset=utf-8'});return res.end(JSON.stringify({error:e.message}));}finally{fs.rmSync(temp,{force:true});}
 }
 const t=resolvePath(req.url||'/');if(!t){res.writeHead(404);return res.end('Not found');}
 if(t.json){const data=Buffer.from(JSON.stringify(t.json));res.writeHead(200,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});return res.end(data);}
 if(t.raw){res.writeHead(200,{'content-type':t.type||'application/octet-stream','cache-control':'no-store'});return res.end(t.raw);}
 fs.readFile(t.file,(err,data)=>{if(err){res.writeHead(err.code==='ENOENT'?404:500);return res.end(err.code==='ENOENT'?'Not found':'Server error');}res.writeHead(200,{'content-type':MIME[path.extname(t.file)]||'application/octet-stream','cache-control':'no-store'});res.end(data);});
}
if(require.main===module){const port=Number(process.env.PORT||8090);const host=process.env.TABLETOP_HTTP_HOST||'0.0.0.0';http.createServer(serve).listen(port,host,()=>console.log(`Tabletop launcher: http://0.0.0.0:${port} packs=${packHost.packDir}`));}
module.exports={serve,packHost,catalog};
