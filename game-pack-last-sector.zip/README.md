# Last Sector ruleset

This package is a game implementation on top of the genre-neutral engine.
It does not modify or import card domains.

## Included in the engine migration

- hex/offset grid generation
- deterministic board randomization
- ships and ship stats
- movement and fuel
- cargo and loot
- planet/station/base delivery
- scan
- combat
- steal
- repair / fuel / trap commands
- tanker attack
- anomalies / pirates / nebula / signal / teleport / accelerator
- player elimination
- victory and score projection
- hidden map information
- deterministic RNG
- save/load through the engine

## Intentionally kept outside the kernel

- rendering and TV presentation
- WebSocket transport
- lobby UI
- browser UI
- AI policy
- wall-clock timing

AI and presentation are adapters over the ruleset; they are not engine primitives.
