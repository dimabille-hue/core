# Last Sector

Standalone Tabletop Game Pack.

Install this ZIP into the engine's game-packs/ directory. The engine discovers the manifest automatically.
