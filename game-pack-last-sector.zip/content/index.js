'use strict';
const fs = require('fs');
const path = require('path');
const { createContentPack } = require(require('node:path').join(process.env.TABLETOP_ENGINE_API_ROOT, 'core', 'content', 'pack'));
const raw = JSON.parse(fs.readFileSync(path.join(__dirname, 'pack.json'), 'utf8'));
module.exports = createContentPack(raw);
