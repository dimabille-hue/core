// AUTO-GENERATED BROWSER MODULE. DO NOT EDIT.
// Source: games/last-sector/client-state.js
// Source SHA-256: ff10aa0411747ba6dc7d6485abd6eb23ebebb06c28e9dc0614640501b1d403b9

/**
 * Last Sector-specific client reducer. It only handles public state events;
 * the generic ClientStateStore remains completely game-agnostic.
 * The reducer mutates the client-owned projection in place to avoid cloning.
 */
function reduceLastSectorEvent(snapshot, event) {
  if (!snapshot?.state || !event) return snapshot;
  const state = snapshot.state;
  const p = event.payload || {};
  const units = Array.isArray(state.units) ? state.units : null;
  if (!units) return snapshot;
  const findByOwner = owner => units.find(unit => unit.owner === owner && unit.status !== 'destroyed');

  switch (event.type) {
    case 'SHIP_MOVED':
    case 'TELEPORTED':
    case 'FORCED_MOVE': {
      const unit = findByOwner(p.player);
      if (unit && p.to) unit.coord = p.to;
      else if (unit && p.from && p.to) unit.coord = p.to;
      break;
    }
    case 'PLAYER_SHIP_DESTROYED': {
      const unit = units.find(x => x.owner === p.player);
      if (unit) unit.status = 'destroyed';
      break;
    }
    case 'CARGO_DELIVERED': {
      if (p.player != null && Number.isFinite(Number(p.value))) {
        state.scores ||= {};
        state.scores[p.player] = (Number(state.scores[p.player]) || 0) + Number(p.value);
      }
      break;
    }
    case 'SIGNAL_GOOD': {
      if (p.player != null) {
        state.scores ||= {};
        state.scores[p.player] = (Number(state.scores[p.player]) || 0) + 1200;
      }
      break;
    }
    case 'TRAP_PLACED': {
      if (p.player != null && p.player === snapshot.viewer && p.coord) {
        state.traps ||= [];
        if (!state.traps.some(t => t.owner === p.player && t.coord === p.coord)) state.traps.push({ owner: p.player, coord: p.coord });
      }
      break;
    }
    case 'TURN_STARTED':
      if (p.player != null) snapshot.active = p.player;
      break;
    default:
      break;
  }
  return snapshot;
}
export { reduceLastSectorEvent };
